# LAB 3 - MÃ HÓA KHÓA CÔNG KHAI

**Họ tên:** Nguyễn Quang Tiến  
**MSSV:** 1150070044  
**Lớp:** 11TTMT  
**Môi trường:** VS Code + Java 17 trở lên + Maven + SQL Server + SSMS  
**Tài liệu gốc:** `LAB3_HuongDan.pdf` (45 trang)

**Giao diện menu:** Đã chỉnh sát mẫu của thầy: cửa sổ nhỏ, tiêu đề + dòng hướng dẫn, 6 nút theo bố cục **2 hàng × 3 cột**. Thông tin sinh viên được giữ tại tên thư mục và đầu README.

## 1. Các nội dung đã có trong bài

| Phần | File Java | Chức năng |
| --- | --- | --- |
| 3.1 | `RSADemo.java` | RSA 2048/3072 trên console, đo thời gian |
| 3.2 | `frm_RSA.java`, `RSACipher.java` | RSA OAEP SHA-256 trên Swing |
| 3.3 | `frm_ECC.java`, `ECCCipher.java` | ECC P-256, ECDH + HKDF + AES-GCM |
| 3.4 | `frm_RSA_AES.java`, `RSA_AES_Cipher.java` | Mã hóa lai RSA + AES-256-GCM, văn bản dài |
| 3.5 | `frm_ECC_Signature.java`, `ECCSignature.java` | Ký/xác minh ECDSA SHA-256 |
| SQL | `frm_KetNoiSQL.java`, `frm_LichSu.java`, `DbConfig.java`, `HistoryDao.java` | Kết nối và nhật ký `dbo.History` |

**Quan trọng:** Đây là bản dựng bằng Swing thuần Java phù hợp **VS Code**, không cần các file `.form` của NetBeans. Các chức năng/thuật toán và tên lớp bám theo PDF.

## 2. Chuẩn bị VS Code

1. Giải nén ZIP. Bạn sẽ thấy thư mục `LAB_3_1150070044_NguyenQuangTien` chứa `pom.xml`, `src`, `03_SQL_SERVER`.
2. Mở **VS Code → File → Open Folder...** → chọn đúng thư mục `LAB_3_1150070044_NguyenQuangTien` (thư mục chứa `pom.xml`).
3. Cài **Extension Pack for Java** và **Maven for Java** trên VS Code.
4. Máy phải có **JDK 17+** (`java -version`) và **Apache Maven** (`mvn -version`). Nếu chưa có thì cài JDK 17/21 và Maven, mở lại VS Code.
5. Chờ VS Code tải dependency trong `pom.xml` (JDBC SQL Server). Bấm **Trust** nếu VS Code hỏi có tin cậy thư mục.
6. Mở `src/main/java/week_03/frm_Menu.java`, chọn **Run Java** ngay phía trên hàm `main`, hoặc chạy tại Terminal:

```powershell
mvn clean compile exec:java "-Dexec.mainClass=week_03.frm_Menu"
```

Nếu thấy giao diện **LAB 3 - MÃ HÓA KHÓA CÔNG KHAI**, bạn đã chạy thành công phần Java.

## 3. Tạo cơ sở dữ liệu SQL Server (làm một lần)

> Chỉ chạy script ở máy thực hành riêng. Không dùng mật khẩu mẫu cho cơ sở dữ liệu quan trọng.

1. Mở **SQL Server Management Studio (SSMS)** → kết nối server của bạn bằng **Windows Authentication** (trước đây bạn dùng server `MSI`).
2. Vào **File → Open → File...** → mở `03_SQL_SERVER/01_Tao_CSDL.sql` → bấm **Execute / F5**. Sau khi xong sẽ có database **LAB3_MaHoaKhoaCongKhai**, bảng **dbo.History**.
3. Mở `03_SQL_SERVER/02_Tao_TaiKhoan_LAB.sql` → **Execute / F5**. Script tạo login **`lab3_user`**, mật khẩu mẫu theo PDF **`LabUser@2026`**. Nếu login này đã tồn tại với mật khẩu khác, script **không đổi** mật khẩu cũ.
4. Kiểm tra **SQL Server and Windows Authentication mode** (Mixed Mode), bật **TCP/IP** và khởi động lại SQL Server sau khi thay đổi cấu hình.
5. Trở lại giao diện Lab 3 → bấm **Kết nối SQL Server**:

   | Ô trong form | Giá trị gợi ý cho máy của bạn |
   | --- | --- |
   | Server/IP | `127.0.0.1` |
   | TCP Port | `1433` |
   | Database | `LAB3_MaHoaKhoaCongKhai` |
   | SQL User | `lab3_user` |
   | Password | `LabUser@2026` nếu chưa đổi |

6. Bấm **Test Connection**. Phải xuất hiện **Kết nối thành công**. Có thể đóng form kết nối, app vẫn nhớ cho đến khi tắt chương trình.

**Lưu ý về port:** PDF của thầy dùng `14333`. Tuy nhiên lần làm LAB 2, máy bạn đã kết nối bằng `127.0.0.1:1433`, nên mẫu này đặt **1433** sẵn. Nếu bạn đổi cổng SQL trong Configuration Manager thì sửa ô **TCP Port** cho khớp. Trong SSMS server dạng `127.0.0.1,1433` (dấu phẩy); trong form Java chỉ điền `127.0.0.1` và `1433` **riêng hai ô**.

## 4. Làm từng bài và quay video/chụp minh chứng

### Bài 3.1 - RSA console (2048 rồi 3072)

Trong terminal VS Code chạy:

```powershell
mvn compile exec:java "-Dexec.mainClass=week_03.RSADemo" "-Dexec.args=2048"
mvn compile exec:java "-Dexec.mainClass=week_03.RSADemo" "-Dexec.args=3072"
```

Kết quả mong đợi: `Decrypted: HELLO RSA`, `Roundtrip: PASS`, Base64 ciphertext **344 ký tự** (2048), **512 ký tự** (3072); thời gian sinh/giải mã không cố định. **Chụp hai màn hình terminal**.

### Bài 3.2 - RSA Swing

1. Trong menu chọn **3.2 - RSA (Swing)**.
2. Chọn **2048** → **Generate Keys**.
3. Plaintext nhập `HELLO RSA` → **Encrypt** → **Decrypt**.
4. Kiểm tra Decrypted đúng `HELLO RSA` → chụp ảnh.
5. Bấm **Encrypt** thêm lần nữa: ciphertext thay đổi do OAEP có tính ngẫu nhiên nhưng vẫn giải mã đúng.
6. Có thể chọn **3072**, bấm Generate Keys rồi thử lại.

### Bài 3.3 - ECC

1. Menu → **3.3 - ECC** → **Generate Keys**.
2. Plaintext `HELLO ECC` → **Encrypt** → **Decrypt**, phải đúng bản rõ. Chụp ảnh.
3. Để kiểm tra sai khóa: **giữ nguyên Ciphertext**, bấm **Generate Keys** lần nữa → bấm **Decrypt**; phải hiện lỗi sai khóa. Chụp ảnh lỗi.
4. Nếu cần khôi phục khóa cũ, hãy **Save Keys** trước khi Generate lại; **Load Keys** chọn thư mục đã lưu.

### Bài 3.4 - RSA + AES (văn bản dài)

1. Menu → **3.4 - Hệ mã lai RSA + AES** → **Generate Keys**.
2. Ô Plaintext đã điền sẵn văn bản **trên 1000 ký tự**; có thể thay bằng văn bản dài của bạn.
3. Bấm **Encrypt** → **Decrypt**, so sánh nội dung hai ô Plaintext/Decrypted. Chụp ảnh.
4. Bấm **Sửa 1 ký tự bản mã** → **Decrypt**: phải báo lỗi do AES-GCM phát hiện dữ liệu bị chỉnh sửa. Chụp ảnh.

### Bài 3.5 - Chữ ký ECDSA

1. Menu → **3.5 - Chữ ký số ECDSA** → **Generate Keys**.
2. Message để `THONG DIEP A` → **Sign** → **Verify**: kết quả màu xanh **VALID**. Chụp ảnh.
3. Bấm **Sửa thông điệp thành B** → **Verify** (không bấm Sign lại): kết quả màu đỏ **INVALID**. Chụp ảnh.

### Lịch sử SQL

1. Phải **Test Connection thành công** trước khi thử các bài.
2. Sau Encrypt/Decrypt/Sign/Verify, quay lại menu → **Xem lịch sử SQL Server** → **Tải lại lịch sử**.
3. Thấy các dòng có `RSA`, `ECC`, `RSA+AES`, `ECDSA` và `ENCRYPT`, `DECRYPT`, `SIGN`, `VERIFY`. Chụp ảnh.
4. Mở SSMS → chạy `03_SQL_SERVER/03_KiemTra_Lich_Su.sql` → chụp danh sách `dbo.History`.

## 5. Gợi ý cấu trúc video và bài nộp

1. Giới thiệu **Nguyễn Quang Tiến - 1150070044 - 11TTMT**.
2. Quay VS Code đang mở `pom.xml`, cây `src/main/java/week_03` và chạy menu.
3. Quay SQL Server tạo database và test kết nối (đừng để lộ mật khẩu).
4. Quay 3.1 RSA console 2048/3072.
5. Quay 3.2 RSA Swing, 3.3 ECC đúng/sai, 3.4 RSA+AES dài/giả mạo, 3.5 ECDSA VALID/INVALID.
6. Quay form lịch sử và truy vấn lịch sử trong SSMS, kết luận.

Nếu nộp GitHub công khai: chỉ đưa lên `README.md`, `pom.xml`, `03_SQL_SERVER/`, `src/` và ảnh/video theo yêu cầu. **KHÔNG nộp** `target/`, mật khẩu thật, file `*_private.key`, file backup DB, hoặc chụp màn hình có khóa riêng/mật khẩu.

## 6. Đưa vào GitHub đúng thư mục MaHoa

Repository trong ảnh của bạn là `1150070044-cyber/LAB_AT_BMHTTT-`.

- Nếu đang ở màn hình GitHub **Create new file** bên trong `MaHoa` (ô **Name your file...**), gõ `LAB_3_1150070044_NguyenQuangTien/README.md`, dán nội dung giới thiệu rồi bấm **Commit changes**. GitHub sẽ tạo thư mục.
- Sau đó vào `MaHoa/LAB_3_1150070044_NguyenQuangTien` → **Add file → Upload files**. Bạn có thể tải lên file ZIP bài làm nếu thầy chấp nhận file nén.
- Để thầy xem trực tiếp từng file Java trên GitHub, cần **upload các file/thư mục đã giải nén** (có thể dùng Git trong VS Code để `git add/commit/push`). **Upload riêng ZIP không tự giải nén thành mã nguồn trên GitHub**.

## 7. Các lỗi thường gặp

| Hiện tượng | Cách xử lý |
| --- | --- |
| `mvn` is not recognized | Cài Maven, thêm `bin` vào PATH, mở terminal mới |
| Java không chạy | Kiểm tra JDK 17 trở lên, extension Java và `pom.xml` |
| `Login failed for user 'lab3_user'` | Kiểm tra script 02, mật khẩu thật, Mixed Mode, khởi động lại dịch vụ |
| SQL network error | Xem TCP/IP Enabled và cổng **1433** hay **14333** thực tế |
| `Invalid object name 'dbo.History'` | Kiểm tra đúng database `LAB3_MaHoaKhoaCongKhai`, chạy script 01 |
| `AEADBadTagException` | Bình thường khi bản mã bị sửa hoặc giải mã bằng khóa ECC/AES sai |
| RSA báo bản rõ quá dài | Chuyển sang bài 3.4 RSA + AES |
| Xem lịch sử trống | Kết nối SQL thành công **trước khi** bấm Encrypt/Sign |

## 8. Kiểm thử nhanh không cần SQL

```powershell
mvn compile exec:java "-Dexec.mainClass=week_03.Lab3SelfTest"
```

Đạt khi thấy 8 dòng `PASS` và `Tất cả kiểm thử mật mã đã PASS.`.
