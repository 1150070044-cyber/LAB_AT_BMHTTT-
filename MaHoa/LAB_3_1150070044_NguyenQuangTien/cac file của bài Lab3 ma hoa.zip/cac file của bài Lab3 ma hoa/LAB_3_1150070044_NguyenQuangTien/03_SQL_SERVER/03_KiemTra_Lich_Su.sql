USE LAB3_MaHoaKhoaCongKhai;
GO
SELECT TOP (100)
    Id, CreatedAt, Algorithm, Operation, InputLength, Success
FROM dbo.History
ORDER BY Id DESC;
GO
SELECT Algorithm, Operation, Success, COUNT(*) AS SoLan
FROM dbo.History
GROUP BY Algorithm, Operation, Success
ORDER BY Algorithm, Operation, Success;
GO
