-- LAB 3 - Tai khoan SQL chi duoc SELECT/INSERT nhat ky.
-- Mat khau MAU theo huong dan LAB3_HuongDan.pdf: LabUser@2026.
-- Chi dung tren may thuc hanh ca nhan; KHONG dang mat khau that len GitHub.
-- Chay sau script 01, bang tai khoan quan tri; bat SQL Server + Windows Authentication.
USE master;
GO
IF SUSER_ID(N'lab3_user') IS NULL
BEGIN
    CREATE LOGIN lab3_user WITH PASSWORD = 'LabUser@2026', CHECK_POLICY = ON;
END;
GO
USE LAB3_MaHoaKhoaCongKhai;
GO
IF DATABASE_PRINCIPAL_ID(N'lab3_user') IS NULL
BEGIN
    CREATE USER lab3_user FOR LOGIN lab3_user;
END;
GO
GRANT SELECT, INSERT ON OBJECT::dbo.History TO lab3_user;
GO
