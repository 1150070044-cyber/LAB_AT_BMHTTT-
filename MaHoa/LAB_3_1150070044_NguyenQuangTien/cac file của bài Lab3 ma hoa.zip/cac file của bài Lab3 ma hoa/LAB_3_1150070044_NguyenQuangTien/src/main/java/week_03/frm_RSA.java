package week_03;

public final class frm_RSA extends CipherWindow {
    public frm_RSA() {
        super("BÀI 3.2 - RSA OAEP SHA-256", new RSACipher(), "RSA", "rsa", "HELLO RSA", true, false);
    }
}
