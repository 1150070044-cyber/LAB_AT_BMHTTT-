package week_03;

/** Bài 3.1 RSA console. Truyền đối số 2048 hoặc 3072. */
public final class RSADemo {
    private RSADemo() { }

    public static void main(String[] args) throws Exception {
        int bits = args.length == 0 ? 2048 : Integer.parseInt(args[0]);
        RSACipher rsa = new RSACipher();
        rsa.setKeySize(bits);
        long start = System.nanoTime();
        rsa.generateKeys();
        double generateMs = (System.nanoTime() - start) / 1_000_000.0;
        String plaintext = "HELLO RSA";
        start = System.nanoTime();
        String encrypted = rsa.encrypt(plaintext);
        double encryptMs = (System.nanoTime() - start) / 1_000_000.0;
        start = System.nanoTime();
        String decrypted = rsa.decrypt(encrypted);
        double decryptMs = (System.nanoTime() - start) / 1_000_000.0;

        System.out.println("=== LAB 3.1 RSA-" + bits + " (OAEP SHA-256) ===");
        System.out.println("Plaintext: " + plaintext);
        System.out.println("Ciphertext Base64: " + encrypted);
        System.out.println("Ciphertext length: " + encrypted.length() + " chars");
        System.out.println("Decrypted: " + decrypted);
        System.out.printf("Generate: %.2f ms | Encrypt: %.2f ms | Decrypt: %.2f ms%n",
            generateMs, encryptMs, decryptMs);
        System.out.println("Roundtrip: " + (plaintext.equals(decrypted) ? "PASS" : "FAIL"));
        System.out.println("Không in private key ra console để tránh lộ khi quay video.");
    }
}
