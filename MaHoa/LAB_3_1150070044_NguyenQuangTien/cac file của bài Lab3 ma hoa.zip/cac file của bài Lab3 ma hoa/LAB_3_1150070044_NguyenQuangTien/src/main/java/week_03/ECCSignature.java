package week_03;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/** Chu ky so ECDSA tren P-256 voi SHA-256. */
public final class ECCSignature {
    private PublicKey publicKey;
    private PrivateKey privateKey;

    public void generateKeys() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
        generator.initialize(new ECGenParameterSpec("secp256r1"));
        KeyPair pair = generator.generateKeyPair();
        publicKey = pair.getPublic();
        privateKey = pair.getPrivate();
    }

    public String sign(String message) throws Exception {
        if (privateKey == null) throw new IllegalStateException("Ban chua Generate Keys/Load Keys.");
        Signature signature = Signature.getInstance("SHA256withECDSA");
        signature.initSign(privateKey);
        signature.update(CryptoSupport.utf8(message));
        return CryptoSupport.b64(signature.sign());
    }

    public boolean verify(String message, String signatureB64) throws Exception {
        if (publicKey == null) throw new IllegalStateException("Ban chua co public key.");
        Signature signature = Signature.getInstance("SHA256withECDSA");
        signature.initVerify(publicKey);
        signature.update(CryptoSupport.utf8(message));
        try {
            return signature.verify(CryptoSupport.unb64(signatureB64));
        } catch (SignatureException | IllegalArgumentException ex) {
            return false;
        }
    }

    public String getPublicKeyBase64() {
        return publicKey == null ? "" : CryptoSupport.b64(publicKey.getEncoded());
    }

    public String getPrivateKeyBase64() {
        return privateKey == null ? "" : CryptoSupport.b64(privateKey.getEncoded());
    }

    public void loadKeys(String publicB64, String privateB64) throws Exception {
        KeyFactory factory = KeyFactory.getInstance("EC");
        PublicKey loadedPublic = factory.generatePublic(new X509EncodedKeySpec(CryptoSupport.unb64(publicB64)));
        PrivateKey loadedPrivate = privateB64.isBlank() ? null :
            factory.generatePrivate(new PKCS8EncodedKeySpec(CryptoSupport.unb64(privateB64)));
        publicKey = loadedPublic;
        privateKey = loadedPrivate;
    }
}
