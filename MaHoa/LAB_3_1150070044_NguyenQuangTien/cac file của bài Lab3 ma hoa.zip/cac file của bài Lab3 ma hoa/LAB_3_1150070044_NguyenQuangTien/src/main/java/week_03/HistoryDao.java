package week_03;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/** Lịch sử chỉ gồm tên thuật toán, thao tác, độ dài, trạng thái; không lưu nội dung/khóa. */
public final class HistoryDao {
    private HistoryDao() { }

    public static void insert(String algorithm, String operation, int inputLength, boolean success)
            throws SQLException {
        String sql = "INSERT INTO dbo.History (Algorithm, Operation, InputLength, Success) VALUES (?, ?, ?, ?)";
        try (Connection connection = DbConfig.open();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, algorithm);
            statement.setString(2, operation);
            statement.setInt(3, inputLength);
            statement.setBoolean(4, success);
            statement.executeUpdate();
        }
    }

    public static String tryInsert(String algorithm, String operation, int inputLength, boolean success) {
        if (!DbConfig.isReady()) return "(Chưa kết nối SQL - chưa ghi lịch sử)";
        try {
            insert(algorithm, operation, inputLength, success);
            return "(Đã ghi vào SQL Server)";
        } catch (SQLException ex) {
            return "(Không lưu được SQL: " + ex.getMessage() + ")";
        }
    }

    public static DefaultTableModel emptyModel() {
        return new DefaultTableModel(new String[]{"Id", "Thời gian", "Thuật toán", "Thao tác", "Độ dài", "Thành công"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    public static DefaultTableModel loadLatest(int top) throws SQLException {
        DefaultTableModel model = emptyModel();
        String sql = "SELECT TOP (?) Id, CreatedAt, Algorithm, Operation, InputLength, Success"
            + " FROM dbo.History ORDER BY Id DESC";
        try (Connection connection = DbConfig.open();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, top);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{rs.getLong(1), rs.getTimestamp(2),
                        rs.getString(3), rs.getString(4), rs.getInt(5), rs.getBoolean(6) ? "Có" : "Không"});
                }
            }
        }
        return model;
    }
}
