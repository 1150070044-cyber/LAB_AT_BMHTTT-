package week_03;

import java.awt.Component;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/** Lưu/đọc khóa Base64 ở thư mục do người dùng chọn; KHÔNG đẩy private key lên GitHub. */
public final class FileTextIO {
    private FileTextIO() { }

    public static boolean saveKeys(Component parent, String name, String publicKey, String privateKey) throws Exception {
        if (publicKey.isBlank() || privateKey.isBlank()) {
            throw new IllegalStateException("Cần Generate Keys trước khi lưu.");
        }
        Path folder = chooseDirectory(parent, "Chọn THƯ MỤC lưu khóa (để riêng, không upload)");
        if (folder == null) return false;
        Path publicPath = folder.resolve(name + "_public.key");
        Path privatePath = folder.resolve(name + "_private.key");
        if ((Files.exists(publicPath) || Files.exists(privatePath))
                && JOptionPane.showConfirmDialog(parent, "Tệp khóa đã tồn tại. Ghi đè?", "Xác nhận",
                    JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return false;
        Files.writeString(publicPath, publicKey, StandardCharsets.UTF_8);
        Files.writeString(privatePath, privateKey, StandardCharsets.UTF_8);
        JOptionPane.showMessageDialog(parent, "Đã lưu 2 khóa tại: " + folder
            + "\nĐừng đưa file _private.key lên GitHub hoặc chụp ảnh khóa riêng.");
        return true;
    }

    public static String[] loadKeys(Component parent, String name) throws Exception {
        Path folder = chooseDirectory(parent, "Chọn thư mục chứa các tệp " + name + "_*.key");
        if (folder == null) return null;
        Path publicPath = folder.resolve(name + "_public.key");
        Path privatePath = folder.resolve(name + "_private.key");
        String pub = Files.readString(publicPath, StandardCharsets.UTF_8).strip();
        String priv = Files.exists(privatePath) ? Files.readString(privatePath, StandardCharsets.UTF_8).strip() : "";
        return new String[]{pub, priv};
    }

    private static Path chooseDirectory(Component parent, String title) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle(title);
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        return chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION
            ? chooser.getSelectedFile().toPath() : null;
    }
}
