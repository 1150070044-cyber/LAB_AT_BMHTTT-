package week_03;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Menu LAB 3: bố cục 2 hàng x 3 cột theo hình trong LAB3_HuongDan.pdf. */
public final class frm_Menu extends JFrame {
    public frm_Menu() {
        super("LAB 3 - Mã hóa khóa công khai");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(650, 235);
        setMinimumSize(new Dimension(630, 220));
        setLocationRelativeTo(null);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(new Color(219, 223, 229));
        content.setBorder(BorderFactory.createEmptyBorder(17, 18, 15, 18));

        JLabel title = new JLabel("LAB 3 - MÃ HÓA KHÓA CÔNG KHAI");
        title.setFont(new Font("Segoe UI", Font.BOLD, 19));
        title.setAlignmentX(LEFT_ALIGNMENT);
        content.add(title);
        content.add(Box.createVerticalStrut(15));

        JLabel instructions = new JLabel(
            "Chọn một bài để mở form tương ứng (bài 3.1 chạy RSADemo.java bằng Run File):");
        instructions.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        instructions.setAlignmentX(LEFT_ALIGNMENT);
        content.add(instructions);
        content.add(Box.createVerticalStrut(16));

        JPanel buttons = new JPanel(new GridLayout(2, 3, 13, 13));
        buttons.setOpaque(false);
        buttons.setAlignmentX(LEFT_ALIGNMENT);
        buttons.add(FormUi.button("3.2 RSA (Swing)", () -> new frm_RSA().setVisible(true)));
        buttons.add(FormUi.button("3.3 ECC", () -> new frm_ECC().setVisible(true)));
        buttons.add(FormUi.button("3.4 RSA + AES", () -> new frm_RSA_AES().setVisible(true)));
        buttons.add(FormUi.button("3.5 Chữ ký ECDSA", () -> new frm_ECC_Signature().setVisible(true)));
        buttons.add(FormUi.button("Kết nối SQL Server", () -> new frm_KetNoiSQL().setVisible(true)));
        buttons.add(FormUi.button("Xem lịch sử", () -> new frm_LichSu().setVisible(true)));
        content.add(buttons);
        setContentPane(content);
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) { }
        SwingUtilities.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}
