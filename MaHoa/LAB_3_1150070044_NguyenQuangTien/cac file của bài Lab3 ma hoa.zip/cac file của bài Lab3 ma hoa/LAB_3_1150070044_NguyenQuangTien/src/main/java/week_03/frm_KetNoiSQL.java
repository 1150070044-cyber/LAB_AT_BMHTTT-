package week_03;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Arrays;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** Cấu hình và kiểm tra SQL Server của máy sinh viên. */
public final class frm_KetNoiSQL extends JFrame {
    private final JTextField host = new JTextField("127.0.0.1", 24);
    private final JTextField port = new JTextField("1433", 24);
    private final JTextField database = new JTextField("LAB3_MaHoaKhoaCongKhai", 24);
    private final JTextField user = new JTextField("lab3_user", 24);
    private final JPasswordField password = new JPasswordField(24);
    private final JLabel status = new JLabel("Nhập mật khẩu LAB 3 rồi bấm Test Connection.");

    public frm_KetNoiSQL() {
        super("LAB 3 - Kết nối SQL Server");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(680, 430);
        setLocationRelativeTo(null);
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;
        addRow(form, c, 0, "Server/IP:", host);
        addRow(form, c, 1, "TCP Port:", port);
        addRow(form, c, 2, "Database:", database);
        addRow(form, c, 3, "SQL User:", user);
        addRow(form, c, 4, "Password:", password);
        c.gridx = 0;
        c.gridy = 5;
        c.gridwidth = 2;
        form.add(FormUi.button("Test Connection", this::testConnection), c);
        c.gridy = 6;
        form.add(status, c);
        c.gridy = 7;
        form.add(new JLabel("Lưu ý: Theo PDF cổng 14333; máy bạn dùng 1433 thì giữ 1433."), c);
        add(form, BorderLayout.CENTER);
    }

    private static void addRow(JPanel panel, GridBagConstraints c, int row, String name, java.awt.Component input) {
        c.gridy = row;
        c.gridx = 0;
        c.gridwidth = 1;
        c.weightx = 0;
        panel.add(new JLabel(name), c);
        c.gridx = 1;
        c.weightx = 1;
        panel.add(input, c);
    }

    private void testConnection() {
        char[] secret = password.getPassword();
        try {
            int tcpPort = Integer.parseInt(port.getText().strip());
            DbConfig.set(host.getText(), tcpPort, database.getText(), user.getText(), secret);
            String message = DbConfig.test();
            status.setText(message);
            JOptionPane.showMessageDialog(this, message, "Kết nối thành công", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            DbConfig.clear();
            status.setText("Không kết nối được - xem hộp thoại lỗi.");
            FormUi.error(this, ex);
        } finally {
            Arrays.fill(secret, '\0');
        }
    }
}
