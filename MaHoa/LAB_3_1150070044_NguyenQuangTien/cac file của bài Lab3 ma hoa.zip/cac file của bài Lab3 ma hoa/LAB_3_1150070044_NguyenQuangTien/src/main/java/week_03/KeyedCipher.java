package week_03;

/** Giao dien chung cho ba bai ma hoa RSA, ECC, RSA + AES. */
public interface KeyedCipher {
    void generateKeys() throws Exception;
    String encrypt(String plaintext) throws Exception;
    String decrypt(String ciphertext) throws Exception;
    String getPublicKeyBase64();
    String getPrivateKeyBase64();
    void loadKeys(String publicB64, String privateB64) throws Exception;
}
