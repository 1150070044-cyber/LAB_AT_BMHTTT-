package week_03;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/** Hiển thị 100 bản ghi mới nhất trong dbo.History. */
public final class frm_LichSu extends JFrame {
    private final JTable table = new JTable(HistoryDao.emptyModel());
    private final JLabel status = new JLabel("Bấm Tải lịch sử để xem 100 dòng gần nhất.");

    public frm_LichSu() {
        super("LAB 3 - Lịch sử SQL Server");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(950, 530);
        setLocationRelativeTo(null);
        table.setAutoCreateRowSorter(true);
        JPanel top = new JPanel(new BorderLayout());
        top.add(FormUi.button("Tải lại lịch sử", this::reload), BorderLayout.WEST);
        top.add(status, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        reload();
    }

    private void reload() {
        try {
            table.setModel(HistoryDao.loadLatest(100));
            status.setText("Đã tải " + table.getRowCount() + " dòng từ dbo.History.");
        } catch (Exception ex) {
            status.setText("Chưa tải được lịch sử. Hãy kết nối SQL trước.");
            FormUi.error(this, ex);
        }
    }
}
