package week_03;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;

/** Cấu hình SQL Server chỉ trong bộ nhớ phiên chạy, không ghi mật khẩu ra file. */
public final class DbConfig {
    private static String server;
    private static int port;
    private static String database;
    private static String user;
    private static char[] password;

    private DbConfig() { }

    public static synchronized void set(String host, int tcpPort, String db, String username, char[] secret) {
        if (host.isBlank() || db.isBlank() || username.isBlank()) {
            throw new IllegalArgumentException("Server, Database, User không được trống.");
        }
        if (tcpPort < 1 || tcpPort > 65535) {
            throw new IllegalArgumentException("Port phải nằm trong khoảng 1-65535.");
        }
        clear();
        server = host.strip();
        port = tcpPort;
        database = db.strip();
        user = username.strip();
        password = secret.clone();
    }

    public static synchronized void clear() {
        if (password != null) Arrays.fill(password, '\0');
        server = null;
        port = 0;
        database = null;
        user = null;
        password = null;
    }

    public static synchronized boolean isReady() {
        return server != null;
    }

    public static synchronized Connection open() throws SQLException {
        if (!isReady()) {
            throw new SQLException("Chưa kết nối SQL Server. Mở mục Kết nối SQL Server ở menu.");
        }
        String url = "jdbc:sqlserver://" + server + ":" + port
            + ";databaseName=" + database + ";encrypt=true;trustServerCertificate=true;loginTimeout=5";
        return DriverManager.getConnection(url, user, new String(password));
    }

    public static String test() throws SQLException {
        try (Connection connection = open()) {
            return "Kết nối thành công! " + connection.getMetaData().getDatabaseProductName()
                + " | CSDL: " + connection.getCatalog();
        }
    }
}
