package week_03;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAKey;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;

/** RSA-OAEP boc khoa AES-256, AES-GCM ma hoa noi dung dai. */
public final class RSA_AES_Cipher implements KeyedCipher {
    private static final OAEPParameterSpec OAEP = new OAEPParameterSpec(
        "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);
    private static final String RSA_TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
    private PublicKey publicKey;
    private PrivateKey privateKey;

    @Override
    public void generateKeys() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        KeyPair pair = generator.generateKeyPair();
        publicKey = pair.getPublic();
        privateKey = pair.getPrivate();
    }

    @Override
    public String encrypt(String plaintext) throws Exception {
        if (publicKey == null) throw new IllegalStateException("Ban chua Generate Keys/Load Keys.");
        byte[] aesKey = CryptoSupport.randomBytes(32);
        byte[] nonce = CryptoSupport.randomBytes(12);
        byte[] payload = CryptoSupport.gcmEncrypt(aesKey, nonce, CryptoSupport.utf8(plaintext));
        Cipher rsa = Cipher.getInstance(RSA_TRANSFORMATION);
        rsa.init(Cipher.ENCRYPT_MODE, publicKey, OAEP);
        byte[] wrappedKey = rsa.doFinal(aesKey);
        return CryptoSupport.b64(CryptoSupport.concat(wrappedKey, nonce, payload));
    }

    @Override
    public String decrypt(String ciphertext) throws Exception {
        if (privateKey == null) throw new IllegalStateException("Ban chua co private key.");
        byte[] all = CryptoSupport.unb64(ciphertext);
        int wrappedLength = (((RSAKey) privateKey).getModulus().bitLength() + 7) / 8;
        if (all.length < wrappedLength + 12 + 16) {
            throw new IllegalArgumentException("Ban ma RSA+AES qua ngan.");
        }
        byte[] wrappedKey = CryptoSupport.slice(all, 0, wrappedLength);
        byte[] nonce = CryptoSupport.slice(all, wrappedLength, wrappedLength + 12);
        byte[] payload = CryptoSupport.slice(all, wrappedLength + 12, all.length);
        Cipher rsa = Cipher.getInstance(RSA_TRANSFORMATION);
        rsa.init(Cipher.DECRYPT_MODE, privateKey, OAEP);
        byte[] aesKey = rsa.doFinal(wrappedKey);
        return CryptoSupport.text(CryptoSupport.gcmDecrypt(aesKey, nonce, payload));
    }

    @Override
    public String getPublicKeyBase64() {
        return publicKey == null ? "" : CryptoSupport.b64(publicKey.getEncoded());
    }

    @Override
    public String getPrivateKeyBase64() {
        return privateKey == null ? "" : CryptoSupport.b64(privateKey.getEncoded());
    }

    @Override
    public void loadKeys(String publicB64, String privateB64) throws Exception {
        KeyFactory factory = KeyFactory.getInstance("RSA");
        PublicKey loadedPublic = factory.generatePublic(new X509EncodedKeySpec(CryptoSupport.unb64(publicB64)));
        PrivateKey loadedPrivate = privateB64.isBlank() ? null :
            factory.generatePrivate(new PKCS8EncodedKeySpec(CryptoSupport.unb64(privateB64)));
        publicKey = loadedPublic;
        privateKey = loadedPrivate;
    }
}
