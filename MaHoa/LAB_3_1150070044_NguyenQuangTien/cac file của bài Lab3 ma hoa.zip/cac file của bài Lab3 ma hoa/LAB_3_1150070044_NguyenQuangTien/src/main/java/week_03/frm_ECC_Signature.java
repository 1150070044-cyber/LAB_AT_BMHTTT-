package week_03;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.nio.charset.StandardCharsets;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/** Bài 3.5: ký và xác minh chữ ký ECDSA. */
public final class frm_ECC_Signature extends JFrame {
    private final ECCSignature ecdsa = new ECCSignature();
    private final JTextArea publicArea = FormUi.area(2, false);
    private final JTextArea privateArea = FormUi.area(2, false);
    private final JTextArea messageArea = FormUi.area(4, true);
    private final JTextArea signatureArea = FormUi.area(4, true);
    private final JLabel verdict = new JLabel("Chưa xác minh");
    private final JLabel status = new JLabel("Generate Keys -> Sign -> Verify.");

    public frm_ECC_Signature() {
        super("BÀI 3.5 - CHỮ KÝ SỐ ECDSA SHA-256");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(850, 800);
        setLocationRelativeTo(null);

        JPanel stack = new JPanel();
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));
        stack.setBorder(BorderFactory.createEmptyBorder(8, 14, 14, 14));
        stack.add(FormUi.title("BÀI 3.5 - CHỮ KÝ SỐ ECDSA (P-256)"));
        stack.add(FormUi.section("Public key - Base64", publicArea));
        privateArea.setText("[Private key được ẩn để giữ bí mật]");
        stack.add(FormUi.section("Private key (đang ẩn)", privateArea));

        JPanel keys = new JPanel(new FlowLayout(FlowLayout.LEFT));
        keys.add(FormUi.button("Generate Keys", this::generate));
        keys.add(FormUi.button("Save Keys", this::save));
        keys.add(FormUi.button("Load Keys", this::load));
        stack.add(keys);

        messageArea.setText("THONG DIEP A");
        stack.add(FormUi.section("Message / Thông điệp", messageArea));
        stack.add(FormUi.section("Signature / Chữ ký Base64", signatureArea));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        actions.add(FormUi.button("Sign", this::sign));
        actions.add(FormUi.button("Verify", this::verify));
        actions.add(FormUi.button("Sửa thông điệp thành B", () -> {
            messageArea.setText("THONG DIEP B");
            status.setText("Đã thay đổi nội dung, bấm Verify (phải là INVALID).");
        }));
        stack.add(actions);
        verdict.setFont(verdict.getFont().deriveFont(21f));
        stack.add(verdict);
        stack.add(status);
        add(new JScrollPane(stack), BorderLayout.CENTER);
    }

    private void refreshKeys() {
        publicArea.setText(ecdsa.getPublicKeyBase64());
        privateArea.setText(ecdsa.getPrivateKeyBase64().isBlank()
            ? "[Chưa có private key]" : "[Đã có private key - đang ẩn]");
    }

    private void generate() {
        try {
            ecdsa.generateKeys();
            refreshKeys();
            status.setText("Đã tạo cặp khóa ECDSA.");
        } catch (Exception ex) { FormUi.error(this, ex); }
    }

    private void save() {
        try {
            FileTextIO.saveKeys(this, "ecdsa", ecdsa.getPublicKeyBase64(), ecdsa.getPrivateKeyBase64());
        } catch (Exception ex) { FormUi.error(this, ex); }
    }

    private void load() {
        try {
            String[] keys = FileTextIO.loadKeys(this, "ecdsa");
            if (keys != null) {
                ecdsa.loadKeys(keys[0], keys[1]);
                refreshKeys();
                status.setText("Đã Load Keys.");
            }
        } catch (Exception ex) { FormUi.error(this, ex); }
    }

    private void sign() {
        String message = messageArea.getText();
        int length = message.getBytes(StandardCharsets.UTF_8).length;
        try {
            signatureArea.setText(ecdsa.sign(message));
            verdict.setText("Đã ký - hãy bấm Verify");
            verdict.setForeground(new Color(0, 95, 150));
            status.setText("Sign thành công " + HistoryDao.tryInsert("ECDSA", "SIGN", length, true));
        } catch (Exception ex) {
            status.setText("Sign thất bại " + HistoryDao.tryInsert("ECDSA", "SIGN", length, false));
            FormUi.error(this, ex);
        }
    }

    private void verify() {
        String message = messageArea.getText();
        int length = message.getBytes(StandardCharsets.UTF_8).length;
        try {
            boolean valid = ecdsa.verify(message, signatureArea.getText());
            verdict.setText(valid ? "VALID - Chữ ký hợp lệ" : "INVALID - Sai thông điệp, khóa hoặc chữ ký");
            verdict.setForeground(valid ? new Color(0, 125, 45) : Color.RED);
            status.setText("Verify: " + (valid ? "VALID " : "INVALID ")
                + HistoryDao.tryInsert("ECDSA", "VERIFY", length, valid));
        } catch (Exception ex) {
            verdict.setText("INVALID");
            verdict.setForeground(Color.RED);
            status.setText("Verify thất bại " + HistoryDao.tryInsert("ECDSA", "VERIFY", length, false));
            FormUi.error(this, ex);
        }
    }
}
