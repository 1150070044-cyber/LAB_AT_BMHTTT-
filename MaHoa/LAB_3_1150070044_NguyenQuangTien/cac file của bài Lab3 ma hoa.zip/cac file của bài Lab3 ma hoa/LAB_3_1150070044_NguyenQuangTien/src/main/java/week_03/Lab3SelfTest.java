package week_03;

/** Kiểm thử độc lập, không cần giao diện hoặc SQL Server. */
public final class Lab3SelfTest {
    private Lab3SelfTest() { }

    private static void check(boolean condition, String test) {
        if (!condition) throw new AssertionError("FAIL: " + test);
        System.out.println("PASS: " + test);
    }

    private static String changeTag(String base64) {
        int offset = base64.length() - 5;
        char newChar = base64.charAt(offset) == 'A' ? 'B' : 'A';
        return base64.substring(0, offset) + newChar + base64.substring(offset + 1);
    }

    public static void main(String[] args) throws Exception {
        RSACipher rsa = new RSACipher();
        rsa.setKeySize(2048);
        rsa.generateKeys();
        check(rsa.decrypt(rsa.encrypt("HELLO RSA")).equals("HELLO RSA"), "RSA-2048 roundtrip");
        rsa.setKeySize(3072);
        rsa.generateKeys();
        check(rsa.decrypt(rsa.encrypt("HELLO RSA")).equals("HELLO RSA"), "RSA-3072 roundtrip");

        ECCCipher ecc = new ECCCipher();
        ecc.generateKeys();
        String ciphertext = ecc.encrypt("HELLO ECC");
        check(ecc.decrypt(ciphertext).equals("HELLO ECC"), "ECC roundtrip");
        ECCCipher anotherEcc = new ECCCipher();
        anotherEcc.generateKeys();
        try {
            anotherEcc.decrypt(ciphertext);
            throw new AssertionError("FAIL: ECC wrong key");
        } catch (javax.crypto.AEADBadTagException expected) {
            System.out.println("PASS: ECC wrong key rejected");
        }

        RSA_AES_Cipher hybrid = new RSA_AES_Cipher();
        hybrid.generateKeys();
        String longText = "Văn bản dài cho RSA AES. ".repeat(75);
        String hybridText = hybrid.encrypt(longText);
        check(hybrid.decrypt(hybridText).equals(longText), "RSA+AES >1000 chars roundtrip");
        try {
            hybrid.decrypt(changeTag(hybridText));
            throw new AssertionError("FAIL: RSA+AES modified ciphertext");
        } catch (javax.crypto.AEADBadTagException expected) {
            System.out.println("PASS: RSA+AES ciphertext tampering rejected");
        }

        ECCSignature signing = new ECCSignature();
        signing.generateKeys();
        String signature = signing.sign("THONG DIEP A");
        check(signing.verify("THONG DIEP A", signature), "ECDSA VALID");
        check(!signing.verify("THONG DIEP B", signature), "ECDSA INVALID after edit");
        System.out.println("Tất cả kiểm thử mật mã đã PASS.");
    }
}
