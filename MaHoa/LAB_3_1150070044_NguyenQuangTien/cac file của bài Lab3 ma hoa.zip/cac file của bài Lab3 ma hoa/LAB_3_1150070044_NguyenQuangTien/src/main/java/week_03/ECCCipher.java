package week_03;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.KeyAgreement;

/** ECIES-like: ECDH (secp256r1) + HKDF-SHA256 + AES-256-GCM. */
public final class ECCCipher implements KeyedCipher {
    private static final byte[] INFO = CryptoSupport.utf8("LAB3-ECC-AESGCM");
    private static final int EPH_BYTES = 91; // Public EC P-256 X.509 encoded
    private static final int SALT_BYTES = 16;
    private static final int NONCE_BYTES = 12;

    private PublicKey publicKey;
    private PrivateKey privateKey;

    private static KeyPair freshPair() throws Exception {
        KeyPairGenerator gen = KeyPairGenerator.getInstance("EC");
        gen.initialize(new ECGenParameterSpec("secp256r1"));
        return gen.generateKeyPair();
    }

    @Override
    public void generateKeys() throws Exception {
        KeyPair pair = freshPair();
        publicKey = pair.getPublic();
        privateKey = pair.getPrivate();
    }

    @Override
    public String encrypt(String plaintext) throws Exception {
        if (publicKey == null) throw new IllegalStateException("Ban chua Generate Keys/Load Keys.");
        KeyPair ephemeral = freshPair();
        KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
        agreement.init(ephemeral.getPrivate());
        agreement.doPhase(publicKey, true);
        byte[] salt = CryptoSupport.randomBytes(SALT_BYTES);
        byte[] nonce = CryptoSupport.randomBytes(NONCE_BYTES);
        byte[] key = CryptoSupport.hkdf(agreement.generateSecret(), salt, INFO);
        byte[] payload = CryptoSupport.gcmEncrypt(key, nonce, CryptoSupport.utf8(plaintext));
        return CryptoSupport.b64(CryptoSupport.concat(ephemeral.getPublic().getEncoded(), salt, nonce, payload));
    }

    @Override
    public String decrypt(String ciphertext) throws Exception {
        if (privateKey == null) throw new IllegalStateException("Ban chua co private key.");
        byte[] all = CryptoSupport.unb64(ciphertext);
        if (all.length < EPH_BYTES + SALT_BYTES + NONCE_BYTES + 16) {
            throw new IllegalArgumentException("Ban ma ECC qua ngan.");
        }
        PublicKey ephemeral = KeyFactory.getInstance("EC").generatePublic(
            new X509EncodedKeySpec(CryptoSupport.slice(all, 0, EPH_BYTES)));
        byte[] salt = CryptoSupport.slice(all, EPH_BYTES, EPH_BYTES + SALT_BYTES);
        byte[] nonce = CryptoSupport.slice(all, EPH_BYTES + SALT_BYTES, EPH_BYTES + SALT_BYTES + NONCE_BYTES);
        byte[] payload = CryptoSupport.slice(all, EPH_BYTES + SALT_BYTES + NONCE_BYTES, all.length);
        KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
        agreement.init(privateKey);
        agreement.doPhase(ephemeral, true);
        byte[] key = CryptoSupport.hkdf(agreement.generateSecret(), salt, INFO);
        return CryptoSupport.text(CryptoSupport.gcmDecrypt(key, nonce, payload));
    }

    @Override
    public String getPublicKeyBase64() {
        return publicKey == null ? "" : CryptoSupport.b64(publicKey.getEncoded());
    }

    @Override
    public String getPrivateKeyBase64() {
        return privateKey == null ? "" : CryptoSupport.b64(privateKey.getEncoded());
    }

    @Override
    public void loadKeys(String publicB64, String privateB64) throws Exception {
        KeyFactory factory = KeyFactory.getInstance("EC");
        PublicKey newPublic = factory.generatePublic(new X509EncodedKeySpec(CryptoSupport.unb64(publicB64)));
        PrivateKey newPrivate = privateB64.isBlank() ? null :
            factory.generatePrivate(new PKCS8EncodedKeySpec(CryptoSupport.unb64(privateB64)));
        publicKey = newPublic;
        privateKey = newPrivate;
    }
}
