package week_03;

public final class frm_ECC extends CipherWindow {
    public frm_ECC() {
        super("BÀI 3.3 - ECC ECDH + AES-GCM", new ECCCipher(), "ECC", "ecc", "HELLO ECC", false, true);
    }
}
