package week_03;

public final class frm_RSA_AES extends CipherWindow {
    public frm_RSA_AES() {
        super("BÀI 3.4 - HỆ MÃ LAI RSA + AES-GCM", new RSA_AES_Cipher(), "RSA+AES", "hybrid",
            "Đây là văn bản dài để thử nghiệm hệ mã lai RSA+AES. ".repeat(28), false, true);
    }
}
