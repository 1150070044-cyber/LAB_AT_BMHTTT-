package week_03;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.nio.charset.StandardCharsets;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/** Form chung cho các bài 3.2 (RSA), 3.3 (ECC), 3.4 (RSA+AES). */
public class CipherWindow extends JFrame {
    private final KeyedCipher cipher;
    private final String algorithm;
    private final String keyFileName;
    private final JTextArea publicArea = FormUi.area(2, false);
    private final JTextArea privateArea = FormUi.area(2, false);
    private final JTextArea plainArea = FormUi.area(4, true);
    private final JTextArea encryptedArea = FormUi.area(6, true);
    private final JTextArea decryptedArea = FormUi.area(4, false);
    private final JLabel status = new JLabel("Bấm Generate Keys để bắt đầu.");
    private final JComboBox<String> sizes = new JComboBox<>(new String[]{"2048", "3072"});

    protected CipherWindow(String title, KeyedCipher engine, String algorithm,
                           String keyFileName, String initialText, boolean rsaMode, boolean tamper) {
        super(title);
        this.cipher = engine;
        this.algorithm = algorithm;
        this.keyFileName = keyFileName;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(860, 850);
        setLocationRelativeTo(null);

        JPanel stack = new JPanel();
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));
        stack.setBorder(BorderFactory.createEmptyBorder(8, 14, 12, 14));
        stack.add(FormUi.title(title));
        stack.add(FormUi.section("Public key - Base64 (X.509)", publicArea));
        privateArea.setText("[Khóa riêng đang ẩn - được giữ trong bộ nhớ]");
        stack.add(FormUi.section("Private key (ẩn để không lộ trong video)", privateArea));

        JPanel keyButtons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        if (rsaMode) {
            keyButtons.add(new JLabel("RSA bits:"));
            keyButtons.add(sizes);
        }
        keyButtons.add(FormUi.button("Generate Keys", this::generateKeys));
        keyButtons.add(FormUi.button("Save Keys", this::saveKeys));
        keyButtons.add(FormUi.button("Load Keys", this::loadKeys));
        stack.add(keyButtons);

        plainArea.setText(initialText);
        stack.add(FormUi.section("Plaintext / Bản rõ", plainArea));
        stack.add(FormUi.section("Ciphertext / Bản mã Base64", encryptedArea));
        stack.add(FormUi.section("Decrypted / Kết quả giải mã", decryptedArea));

        JPanel operations = new JPanel(new FlowLayout(FlowLayout.LEFT));
        operations.add(FormUi.button("Encrypt", this::encrypt));
        operations.add(FormUi.button("Decrypt", this::decrypt));
        if (tamper) {
            operations.add(FormUi.button("Sửa 1 ký tự bản mã", this::tamperCiphertext));
        }
        stack.add(operations);
        status.setForeground(new Color(0, 86, 132));
        stack.add(status);
        add(new JScrollPane(stack), BorderLayout.CENTER);
    }

    private void generateKeys() {
        try {
            if (cipher instanceof RSACipher rsa) rsa.setKeySize(Integer.parseInt((String) sizes.getSelectedItem()));
            cipher.generateKeys();
            refreshPublicKey();
            status.setText("Đã tạo cặp khóa mới. Giữ bí mật private key.");
        } catch (Exception ex) {
            FormUi.error(this, ex);
        }
    }

    private void refreshPublicKey() {
        publicArea.setText(cipher.getPublicKeyBase64());
        privateArea.setText(cipher.getPrivateKeyBase64().isBlank()
            ? "[Chưa nạp private key]" : "[Đã có private key - đang ẩn để bảo mật]");
    }

    private void encrypt() {
        String plain = plainArea.getText();
        int bytes = plain.getBytes(StandardCharsets.UTF_8).length;
        try {
            encryptedArea.setText(cipher.encrypt(plain));
            decryptedArea.setText("");
            status.setText("Encrypt thành công " + HistoryDao.tryInsert(algorithm, "ENCRYPT", bytes, true));
        } catch (Exception ex) {
            status.setText("Encrypt thất bại " + HistoryDao.tryInsert(algorithm, "ENCRYPT", bytes, false));
            FormUi.error(this, ex);
        }
    }

    private void decrypt() {
        String encrypted = encryptedArea.getText();
        int count = encrypted.getBytes(StandardCharsets.UTF_8).length;
        try {
            decryptedArea.setText(cipher.decrypt(encrypted));
            status.setText("Decrypt thành công " + HistoryDao.tryInsert(algorithm, "DECRYPT", count, true));
        } catch (Exception ex) {
            decryptedArea.setText("[GIẢI MÃ THẤT BẠI: sai khóa hoặc bản mã bị sửa]");
            status.setText("Decrypt thất bại " + HistoryDao.tryInsert(algorithm, "DECRYPT", count, false));
            FormUi.error(this, ex);
        }
    }

    private void tamperCiphertext() {
        String text = encryptedArea.getText().strip();
        if (text.length() < 8) {
            status.setText("Hãy Encrypt trước khi sửa bản mã.");
            return;
        }
        int index = text.length() - 5; // sửa phần tag AES-GCM, tránh làm hỏng Base64 padding
        char current = text.charAt(index);
        char changed = current == 'A' ? 'B' : 'A';
        encryptedArea.setText(text.substring(0, index) + changed + text.substring(index + 1));
        status.setText("Đã sửa 1 ký tự. Bấm Decrypt -> chương trình phải báo lỗi.");
    }

    private void saveKeys() {
        try {
            FileTextIO.saveKeys(this, keyFileName, cipher.getPublicKeyBase64(), cipher.getPrivateKeyBase64());
        } catch (Exception ex) {
            FormUi.error(this, ex);
        }
    }

    private void loadKeys() {
        try {
            String[] keys = FileTextIO.loadKeys(this, keyFileName);
            if (keys != null) {
                cipher.loadKeys(keys[0], keys[1]);
                refreshPublicKey();
                status.setText("Đã Load Keys. Có thể Encrypt/Decrypt.");
            }
        } catch (Exception ex) {
            FormUi.error(this, ex);
        }
    }
}
