package week_03;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAKey;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;

/** RSA-OAEP SHA-256: RSA-2048 toi da 190 bytes; RSA-3072 toi da 318 bytes. */
public final class RSACipher implements KeyedCipher {
    private static final String TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding";
    private static final OAEPParameterSpec OAEP = new OAEPParameterSpec(
        "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);

    private PublicKey publicKey;
    private PrivateKey privateKey;
    private int bits = 2048;

    public void setKeySize(int newBits) {
        if (newBits != 2048 && newBits != 3072) {
            throw new IllegalArgumentException("RSA chi ho tro 2048/3072 bit cho bai lab.");
        }
        bits = newBits;
    }

    public int keySize() {
        return publicKey == null ? bits : ((RSAKey) publicKey).getModulus().bitLength();
    }

    @Override
    public void generateKeys() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(bits);
        KeyPair pair = generator.generateKeyPair();
        publicKey = pair.getPublic();
        privateKey = pair.getPrivate();
    }

    @Override
    public String encrypt(String plaintext) throws Exception {
        if (publicKey == null) throw new IllegalStateException("Ban chua Generate Keys/Load Keys.");
        byte[] bytes = CryptoSupport.utf8(plaintext);
        int max = ((RSAKey) publicKey).getModulus().bitLength() / 8 - 66;
        if (bytes.length > max) {
            throw new IllegalArgumentException("RSA-" + keySize() + " toi da " + max
                + " byte UTF-8. Van ban dai hay dung bai 3.4 RSA + AES.");
        }
        Cipher rsa = Cipher.getInstance(TRANSFORMATION);
        rsa.init(Cipher.ENCRYPT_MODE, publicKey, OAEP);
        return CryptoSupport.b64(rsa.doFinal(bytes));
    }

    @Override
    public String decrypt(String ciphertext) throws Exception {
        if (privateKey == null) throw new IllegalStateException("Ban chua co private key.");
        Cipher rsa = Cipher.getInstance(TRANSFORMATION);
        rsa.init(Cipher.DECRYPT_MODE, privateKey, OAEP);
        return CryptoSupport.text(rsa.doFinal(CryptoSupport.unb64(ciphertext)));
    }

    @Override
    public String getPublicKeyBase64() {
        return publicKey == null ? "" : CryptoSupport.b64(publicKey.getEncoded());
    }

    @Override
    public String getPrivateKeyBase64() {
        return privateKey == null ? "" : CryptoSupport.b64(privateKey.getEncoded());
    }

    @Override
    public void loadKeys(String publicB64, String privateB64) throws Exception {
        KeyFactory factory = KeyFactory.getInstance("RSA");
        PublicKey loadedPublic = factory.generatePublic(new X509EncodedKeySpec(CryptoSupport.unb64(publicB64)));
        PrivateKey loadedPrivate = privateB64.isBlank() ? null :
            factory.generatePrivate(new PKCS8EncodedKeySpec(CryptoSupport.unb64(privateB64)));
        publicKey = loadedPublic;
        privateKey = loadedPrivate;
        bits = ((RSAKey) loadedPublic).getModulus().bitLength();
    }
}
