package week_03;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Ham dung chung: UTF-8, Base64, HKDF-SHA256 va AES-256-GCM. */
public final class CryptoSupport {
    private static final SecureRandom RANDOM = new SecureRandom();

    private CryptoSupport() { }

    public static byte[] utf8(String text) {
        return text.getBytes(StandardCharsets.UTF_8);
    }

    public static String text(byte[] bytes) {
        return new String(bytes, StandardCharsets.UTF_8);
    }

    public static String b64(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }

    public static byte[] unb64(String encoded) {
        return Base64.getMimeDecoder().decode(encoded.strip());
    }

    public static byte[] randomBytes(int count) {
        byte[] result = new byte[count];
        RANDOM.nextBytes(result);
        return result;
    }

    public static byte[] concat(byte[]... parts) {
        int count = 0;
        for (byte[] part : parts) {
            count += part.length;
        }
        byte[] result = new byte[count];
        int index = 0;
        for (byte[] part : parts) {
            System.arraycopy(part, 0, result, index, part.length);
            index += part.length;
        }
        return result;
    }

    public static byte[] slice(byte[] bytes, int from, int to) {
        if (from < 0 || to < from || to > bytes.length) {
            throw new IllegalArgumentException("Ban ma khong du do dai hoac sai dinh dang.");
        }
        return Arrays.copyOfRange(bytes, from, to);
    }

    /** HKDF SHA-256: extract + expand, lay 32 byte cho AES-256. */
    public static byte[] hkdf(byte[] secret, byte[] salt, byte[] info) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(salt, "HmacSHA256"));
        byte[] prk = mac.doFinal(secret);
        mac.init(new SecretKeySpec(prk, "HmacSHA256"));
        mac.update(info);
        mac.update((byte) 0x01);
        return mac.doFinal(); // 32 bytes
    }

    public static byte[] gcmEncrypt(byte[] aesKey, byte[] nonce, byte[] plain) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(aesKey, "AES"), new GCMParameterSpec(128, nonce));
        return cipher.doFinal(plain);
    }

    public static byte[] gcmDecrypt(byte[] aesKey, byte[] nonce, byte[] encrypted) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(aesKey, "AES"), new GCMParameterSpec(128, nonce));
        return cipher.doFinal(encrypted); // sai khoa/sua ban ma -> AEADBadTagException
    }
}
