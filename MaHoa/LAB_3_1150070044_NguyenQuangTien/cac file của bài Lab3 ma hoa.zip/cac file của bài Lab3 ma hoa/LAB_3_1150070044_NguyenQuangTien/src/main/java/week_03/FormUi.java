package week_03;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

/** Một vài hàm giao diện chung để làm Swing thuần Java, không cần .form NetBeans. */
public final class FormUi {
    private FormUi() { }

    public static JTextArea area(int rows, boolean editable) {
        JTextArea area = new JTextArea(rows, 65);
        area.setEditable(editable);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        return area;
    }

    public static JPanel section(String title, JTextArea area) {
        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.setBorder(BorderFactory.createTitledBorder(title));
        JScrollPane scrollPane = new JScrollPane(area);
        scrollPane.setPreferredSize(new Dimension(680, Math.min(160, 28 + area.getRows() * 20)));
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    public static JLabel title(String name) {
        JLabel label = new JLabel(name, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, 19));
        label.setBorder(BorderFactory.createEmptyBorder(12, 4, 12, 4));
        return label;
    }

    public static JButton button(String caption, Runnable action) {
        JButton button = new JButton(caption);
        button.addActionListener(event -> action.run());
        return button;
    }

    public static String simpleError(Throwable exception) {
        String name = exception.getClass().getSimpleName();
        if (name.equals("AEADBadTagException") || name.equals("BadPaddingException")) {
            return "Giải mã thất bại: sai khóa hoặc bản mã bị sửa.";
        }
        String message = exception.getMessage();
        return message == null || message.isBlank() ? name : message;
    }

    public static void error(Component owner, Throwable exception) {
        JOptionPane.showMessageDialog(owner, simpleError(exception), "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
}
