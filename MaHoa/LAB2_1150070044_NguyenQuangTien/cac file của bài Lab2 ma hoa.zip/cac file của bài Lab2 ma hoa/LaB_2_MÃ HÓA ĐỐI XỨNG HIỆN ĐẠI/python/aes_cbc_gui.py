"""LAB 2 - AES-256-CBC bằng Python (Tkinter).

Cài: py -m pip install cryptography
Chạy: py python/aes_cbc_gui.py
Test: py python/aes_cbc_gui.py --self-test
"""
import base64
import secrets
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


def new_key() -> str:
    return base64.b64encode(secrets.token_bytes(32)).decode("ascii")


def new_iv() -> str:
    return base64.b64encode(secrets.token_bytes(16)).decode("ascii")


def _key_iv(key_b64: str, iv_b64: str):
    try:
        key = base64.b64decode(key_b64.strip(), validate=True)
        iv = base64.b64decode(iv_b64.strip(), validate=True)
    except Exception as ex:
        raise ValueError("Key/IV phải là chuỗi Base64 hợp lệ.") from ex
    if len(key) != 32 or len(iv) != 16:
        raise ValueError("Key phải 32 byte và IV phải 16 byte. Hãy bấm Generate.")
    return key, iv


def encrypt_text(plaintext: str, key_b64: str, iv_b64: str) -> str:
    key, iv = _key_iv(key_b64, iv_b64)
    padder = padding.PKCS7(128).padder()
    padded = padder.update(plaintext.encode("utf-8")) + padder.finalize()
    encryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
    return base64.b64encode(encryptor.update(padded) + encryptor.finalize()).decode("ascii")


def decrypt_text(ciphertext_b64: str, key_b64: str, iv_b64: str) -> str:
    key, iv = _key_iv(key_b64, iv_b64)
    try:
        data = base64.b64decode(ciphertext_b64.strip(), validate=True)
    except Exception as ex:
        raise ValueError("Ciphertext phải là Base64 hợp lệ.") from ex
    if not data or len(data) % 16:
        raise ValueError("Độ dài bản mã AES-CBC phải là bội số 16 byte.")
    try:
        decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
        padded = decryptor.update(data) + decryptor.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        return (unpadder.update(padded) + unpadder.finalize()).decode("utf-8")
    except Exception as ex:
        raise ValueError("Giải mã thất bại: sai Key/IV hoặc bản mã đã bị sửa.") from ex


def self_test():
    key, iv = new_key(), new_iv()
    long_text = "Văn bản dài tiếng Việt có dấu. " * 200
    for msg in ["Xin chào AES-CBC", "", "1234567890123456", long_text]:
        assert decrypt_text(encrypt_text(msg, key, iv), key, iv) == msg
    c = encrypt_text("abc", key, iv)
    assert len(base64.b64decode(c)) == 16
    try:
        decrypt_text(c, new_key(), iv)
        raise AssertionError("Sai key phải báo lỗi")
    except ValueError:
        pass
    print("SELF-TEST OK: AES-CBC mã hóa/giải mã chính xác; phát hiện sai khóa.")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LAB 2 - AES-CBC Python")
        self.geometry("720x580")
        self.resizable(False, False)
        self.key = tk.StringVar()
        self.iv = tk.StringVar()
        self.status = tk.StringVar(value="Sẵn sàng.")
        frame = ttk.Frame(self, padding=15)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="BÀI NÂNG CAO 02 - AES-256-CBC (PYTHON)", font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 10))
        ttk.Label(frame, text="Plaintext:").pack(anchor="w")
        self.plain = tk.Text(frame, height=5, wrap="word")
        self.plain.pack(fill="x", pady=(0, 10))
        line1 = ttk.Frame(frame); line1.pack(fill="x", pady=3)
        ttk.Label(line1, text="Key (Base64):", width=16).pack(side="left")
        ttk.Entry(line1, textvariable=self.key, width=62).pack(side="left")
        ttk.Button(line1, text="Generate Key", command=lambda: self.key.set(new_key())).pack(side="left", padx=5)
        line2 = ttk.Frame(frame); line2.pack(fill="x", pady=3)
        ttk.Label(line2, text="IV (Base64):", width=16).pack(side="left")
        ttk.Entry(line2, textvariable=self.iv, width=62).pack(side="left")
        ttk.Button(line2, text="Generate IV", command=lambda: self.iv.set(new_iv())).pack(side="left", padx=5)
        ttk.Label(frame, text="Ciphertext:").pack(anchor="w", pady=(12, 0))
        self.cipher = tk.Text(frame, height=5, wrap="word")
        self.cipher.pack(fill="x", pady=(0, 10))
        actions = ttk.Frame(frame); actions.pack(anchor="w")
        ttk.Button(actions, text="Encrypt", command=self.encrypt).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Decrypt", command=self.decrypt).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Save File", command=self.save).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Open File", command=self.open).pack(side="left")
        ttk.Label(frame, textvariable=self.status).pack(anchor="w", pady=12)

    @staticmethod
    def _get(widget):
        return widget.get("1.0", "end-1c")

    @staticmethod
    def _set(widget, data):
        widget.delete("1.0", "end")
        widget.insert("1.0", data)

    def encrypt(self):
        try:
            self._set(self.cipher, encrypt_text(self._get(self.plain), self.key.get(), self.iv.get()))
            self.status.set("Đã mã hóa AES-CBC.")
        except ValueError as ex:
            messagebox.showerror("Lỗi mã hóa", str(ex))

    def decrypt(self):
        try:
            self._set(self.plain, decrypt_text(self._get(self.cipher), self.key.get(), self.iv.get()))
            self.status.set("Đã giải mã AES-CBC.")
        except ValueError as ex:
            messagebox.showerror("Lỗi giải mã", str(ex))

    def save(self):
        if not self._get(self.cipher).strip():
            messagebox.showwarning("Thiếu dữ liệu", "Chưa có Ciphertext để lưu.")
            return
        filename = filedialog.asksaveasfilename(defaultextension=".txt", initialfile="aes_cbc_ciphertext.txt",
                                               filetypes=[("Text files", "*.txt")])
        if filename:
            with open(filename, "w", encoding="utf-8") as file:
                file.write("IV=" + self.iv.get().strip() + "\n" + self._get(self.cipher).strip() + "\n")
            self.status.set("Đã lưu: " + filename)

    def open(self):
        filename = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if filename:
            with open(filename, encoding="utf-8") as file:
                lines = file.read().strip().split("\n", 1)
            if len(lines) != 2 or not lines[0].startswith("IV="):
                messagebox.showerror("Lỗi định dạng", "Tệp phải có dòng 1 IV=... và dòng 2 Ciphertext.")
                return
            self.iv.set(lines[0][3:].strip())
            self._set(self.cipher, lines[1].strip())
            self.status.set("Đã mở tệp. Nhập lại đúng Key và bấm Decrypt.")


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        self_test()
    else:
        App().mainloop()
