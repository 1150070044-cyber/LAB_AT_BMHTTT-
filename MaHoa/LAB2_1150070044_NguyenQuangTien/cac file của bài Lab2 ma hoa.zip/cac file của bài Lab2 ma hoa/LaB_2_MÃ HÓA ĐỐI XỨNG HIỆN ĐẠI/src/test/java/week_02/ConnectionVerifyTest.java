package week_02;

import javax.swing.table.DefaultTableModel;

public class ConnectionVerifyTest {
    public static void main(String[] args) {
        System.out.println("=== BAT DAU KIEM THU KET NOI JDBC VA CHUC NANG ===");
        try {
            // 1. Ket noi
            char[] pw = "LabUser@2026".toCharArray();
            DbConfig.set("127.0.0.1", 1433, "LAB2_MaHoaHienDai", "lab2_user", pw);
            String testResult = DbConfig.test();
            System.out.println("[PASS] DbConfig.test(): " + testResult);

            // 2. Dang ky & Dang nhap (dbo.app_users)
            String testUsername = "user_test_" + (System.currentTimeMillis() % 10000);
            char[] userPw = "MatKhau@123".toCharArray();
            UserDao.register(testUsername, userPw);
            System.out.println("[PASS] UserDao.register() thanh cong cho user: " + testUsername);

            boolean loginOk = UserDao.login(testUsername, userPw);
            if (!loginOk) throw new RuntimeException("Dang nhap that bai voi mat khau dung!");
            System.out.println("[PASS] UserDao.login() xac thuc thanh cong!");

            boolean wrongLogin = UserDao.login(testUsername, "SaiMatKhau@123".toCharArray());
            if (wrongLogin) throw new RuntimeException("Dang nhap khong duoc phep thanh cong voi mat khau sai!");
            System.out.println("[PASS] UserDao.login() chan thanh cong khi mat khau sai!");

            // 3. Ghi lich su ma hoa (dbo.crypto_history)
            String insertMsg = HistoryDao.tryInsert("AES-GCM", "Mã hóa", testUsername, 48, 64);
            System.out.println("[PASS] HistoryDao.tryInsert() ket qua: " + insertMsg);

            // 4. Doc lich su ma hoa
            DefaultTableModel model = HistoryDao.loadLatest(5);
            System.out.println("[PASS] HistoryDao.loadLatest() doc duoc: " + model.getRowCount() + " dong lich su.");
            for (int r = 0; r < model.getRowCount(); r++) {
                System.out.println("       + ID=" + model.getValueAt(r, 0)
                        + " | Time=" + model.getValueAt(r, 1)
                        + " | Alg=" + model.getValueAt(r, 2)
                        + " | Op=" + model.getValueAt(r, 3)
                        + " | User=" + model.getValueAt(r, 4));
            }

            System.out.println("=== TAT CA KIEM THU DA HOAN TAT VA THANH CONG 100% ===");
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(1);
        }
    }
}
