package week_02;

import java.security.MessageDigest;
import java.util.Arrays;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.engines.TwofishEngine;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;

/** Twofish-CBC với PKCS7 và IV 16 byte dưới dạng HEX. */
public final class TwofishCipher {
    private TwofishCipher() {}
    public static String newIv() { return CipherUtil.hex(CipherUtil.randomBytes(16)); }
    private static byte[] run(boolean encrypt, byte[] input, String keyText, String ivHex) throws Exception {
        CipherUtil.requireKey(keyText);
        byte[] iv = CipherUtil.fromHex(ivHex);
        if (iv.length != 16) throw new IllegalArgumentException("IV phải 16 byte = 32 ký tự HEX. Bấm Generate IV.");
        byte[] key = MessageDigest.getInstance("SHA-256").digest(CipherUtil.utf8(keyText));
        BufferedBlockCipher c = new PaddedBufferedBlockCipher(CBCBlockCipher.newInstance(new TwofishEngine()));
        c.init(encrypt, new ParametersWithIV(new KeyParameter(key), iv));
        byte[] out = new byte[c.getOutputSize(input.length)];
        int n = c.processBytes(input, 0, input.length, out, 0);
        n += c.doFinal(out, n);
        return Arrays.copyOf(out, n);
    }
    public static String encrypt(String plain, String key, String ivHex) throws Exception {
        return CipherUtil.b64(run(true, CipherUtil.utf8(plain), key, ivHex));
    }
    public static String decrypt(String data, String key, String ivHex) throws Exception {
        return CipherUtil.text(run(false, CipherUtil.fromB64(data), key, ivHex));
    }
    public static String toFile(String iv, String data) { return "IV=" + iv.trim() + "\n" + data.trim() + "\n"; }
    public static String[] fromFile(String content) {
        String[] lines = content.trim().split("\\R", 2);
        if (lines.length != 2 || !lines[0].startsWith("IV="))
            throw new IllegalArgumentException("Tệp phải có dòng 1 IV=... và dòng 2 bản mã.");
        return new String[] {lines[0].substring(3).trim(), lines[1].trim()};
    }
}
