package week_02;

import java.awt.*;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Giao diện Swing viết bằng code để chạy trực tiếp trong VS Code, không cần NetBeans .form. */
abstract class CryptoForm extends JFrame {
    @FunctionalInterface interface Action {
        String apply(String data, String key, String aux) throws Exception;
    }

    protected final JTextArea txt_plaintext = area();
    protected final JTextArea txt_ciphertext = area();
    protected final JTextField txt_key = new JTextField(30);
    protected final JTextField txt_aux = new JTextField(33);
    protected final JLabel lbl_status = new JLabel("Sẵn sàng.");
    private final String algorithm;
    private final String saveMode;
    private final Action encryptor, decryptor;
    private final boolean loginRequired;
    private String currentUser;
    private JPasswordField loginPassword;
    private JTextField username, ticket;

    protected CryptoForm(String title, String algorithm, String initialKey,
                         String auxLabel, String initialAux, String saveMode, boolean loginRequired,
                         Action encryptor, Action decryptor) {
        super(title);
        this.algorithm = algorithm;
        this.saveMode = saveMode;
        this.loginRequired = loginRequired;
        this.encryptor = encryptor;
        this.decryptor = decryptor;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(770, loginRequired ? 820 : 650);
        setMinimumSize(new Dimension(650, 540));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBorder(new EmptyBorder(15, 18, 15, 18));
        add(new JScrollPane(main));

        JLabel h = new JLabel("LAB 2 - " + title);
        h.setFont(new Font("Segoe UI", Font.BOLD, 20));
        h.setAlignmentX(Component.LEFT_ALIGNMENT);
        main.add(h);
        main.add(Box.createVerticalStrut(10));

        if (loginRequired) addLoginPanel(main);
        addLabel(main, "Plaintext:");
        main.add(scroller(txt_plaintext));
        main.add(Box.createVerticalStrut(8));

        addLabel(main, loginRequired ? "Key AES (mật khẩu tạo khóa):" :
                "Key" + ("AES-CTR".equals(algorithm) ? " (Base64):" : ":"));
        txt_key.setText(initialKey == null ? "" : initialKey);
        JPanel keyPanel = new JPanel(new BorderLayout(8, 0));
        keyPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        keyPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        keyPanel.add(txt_key, BorderLayout.CENTER);
        if ("AES-CTR".equals(algorithm)) {
            JButton generate = new JButton("Generate Key");
            generate.addActionListener(e -> txt_key.setText(AESCTRCipher.newKey()));
            keyPanel.add(generate, BorderLayout.EAST);
        }
        main.add(keyPanel);
        main.add(Box.createVerticalStrut(7));

        if (auxLabel != null) {
            addLabel(main, auxLabel);
            txt_aux.setText(initialAux == null ? "" : initialAux);
            JPanel auxPanel = new JPanel(new BorderLayout(8, 0));
            auxPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
            auxPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
            auxPanel.add(txt_aux, BorderLayout.CENTER);
            JButton generate = new JButton("Twofish".equals(algorithm) ? "Generate IV" : "Generate Nonce");
            generate.addActionListener(e -> txt_aux.setText("Twofish".equals(algorithm) ? TwofishCipher.newIv() : AESCTRCipher.newNonce()));
            auxPanel.add(generate, BorderLayout.EAST);
            main.add(auxPanel);
            main.add(Box.createVerticalStrut(7));
        }

        addLabel(main, "Ciphertext:");
        main.add(scroller(txt_ciphertext));
        main.add(Box.createVerticalStrut(12));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 4));
        JButton en = new JButton("Encrypt"); en.addActionListener(e -> run(true));
        JButton de = new JButton("Decrypt"); de.addActionListener(e -> run(false));
        JButton save = new JButton("Save File"); save.addActionListener(e -> saveFile());
        JButton open = new JButton("Open File"); open.addActionListener(e -> openFile());
        buttons.add(en); buttons.add(de); buttons.add(save); buttons.add(open);
        buttons.setAlignmentX(Component.LEFT_ALIGNMENT);
        main.add(buttons);
        lbl_status.setAlignmentX(Component.LEFT_ALIGNMENT);
        main.add(lbl_status);
        setLocationRelativeTo(null);
    }

    private static JTextArea area() {
        JTextArea out = new JTextArea(4, 55);
        out.setLineWrap(true); out.setWrapStyleWord(true);
        out.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        return out;
    }
    private static JScrollPane scroller(JTextArea a) {
        JScrollPane s = new JScrollPane(a);
        s.setAlignmentX(Component.LEFT_ALIGNMENT);
        s.setPreferredSize(new Dimension(650, 100));
        return s;
    }
    private static void addLabel(JPanel p, String s) {
        JLabel l = new JLabel(s);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(l);
    }

    private void addLoginPanel(JPanel parent) {
        JPanel block = new JPanel();
        block.setLayout(new BoxLayout(block, BoxLayout.Y_AXIS));
        block.setBorder(BorderFactory.createTitledBorder("AES-GCM - Register / Login (SQL Server)"));
        block.setAlignmentX(Component.LEFT_ALIGNMENT);
        block.setMaximumSize(new Dimension(Integer.MAX_VALUE, 165));
        username = new JTextField("sinhvien01", 18);
        loginPassword = new JPasswordField(18);
        ticket = new JTextField(35); ticket.setEditable(false);
        JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row1.add(new JLabel("Username:")); row1.add(username);
        row1.add(new JLabel("Password:")); row1.add(loginPassword);
        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton sql = new JButton("Kết nối SQL Server"); sql.addActionListener(e -> new frm_KetNoiSQL().setVisible(true));
        JButton reg = new JButton("Register"); reg.addActionListener(e -> register());
        JButton log = new JButton("Login"); log.addActionListener(e -> login());
        row2.add(sql); row2.add(reg); row2.add(log);
        JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row3.add(new JLabel("Ticket:")); row3.add(ticket);
        block.add(row1); block.add(row2); block.add(row3);
        parent.add(block); parent.add(Box.createVerticalStrut(10));
    }
    private void register() {
        char[] pass = loginPassword.getPassword();
        try { UserDao.register(username.getText().trim(), pass); setStatus("Đăng ký thành công. Bấm Login."); }
        catch (Exception ex) { showError(ex); }
        finally { Arrays.fill(pass, '\0'); }
    }
    private void login() {
        char[] pass = loginPassword.getPassword();
        try {
            if (!UserDao.login(username.getText().trim(), pass)) {
                currentUser = null; ticket.setText("");
                throw new IllegalArgumentException("Sai username hoặc mật khẩu.");
            }
            currentUser = username.getText().trim();
            ticket.setText(UserDao.newTicket());
            setStatus("Login thành công. Có thể Encrypt/Decrypt.");
        } catch (Exception ex) { showError(ex); }
        finally { Arrays.fill(pass, '\0'); }
    }
    private void run(boolean encrypt) {
        if (loginRequired && currentUser == null) {
            JOptionPane.showMessageDialog(this, "Hãy đăng nhập trước khi mã hóa/giải mã."); return;
        }
        try {
            String input = encrypt ? txt_plaintext.getText() : txt_ciphertext.getText().trim();
            String output = (encrypt ? encryptor : decryptor).apply(input, txt_key.getText(), txt_aux.getText());
            if (encrypt) txt_ciphertext.setText(output); else txt_plaintext.setText(output);
            String log = HistoryDao.tryInsert(algorithm, encrypt ? "ENCRYPT" : "DECRYPT", currentUser,
                    CipherUtil.utf8(input).length, CipherUtil.utf8(output).length);
            setStatus((encrypt ? "Đã mã hóa. " : "Đã giải mã. ") + log);
        } catch (Exception ex) { showError(ex); }
    }
    private void saveFile() {
        String data = txt_ciphertext.getText();
        if (data.isBlank()) { JOptionPane.showMessageDialog(this, "Chưa có bản mã để lưu."); return; }
        String content = switch (saveMode) {
            case "twofish" -> TwofishCipher.toFile(txt_aux.getText(), data);
            case "ctr" -> AESCTRCipher.toFile(txt_aux.getText(), data);
            default -> data;
        };
        String path = FileTextIO.saveString(this, content, algorithm.toLowerCase().replace('-', '_') + "_ciphertext.txt");
        if (path != null) setStatus("Đã lưu: " + path + " (không lưu Key)");
    }
    private void openFile() {
        String content = FileTextIO.openString(this);
        if (content == null) return;
        try {
            if ("twofish".equals(saveMode)) {
                String[] p = TwofishCipher.fromFile(content);
                txt_aux.setText(p[0]); txt_ciphertext.setText(p[1]);
            } else if ("ctr".equals(saveMode)) {
                String[] p = AESCTRCipher.fromFile(content);
                txt_aux.setText(p[0]); txt_ciphertext.setText(p[1]);
            } else txt_ciphertext.setText(content.trim());
            setStatus("Đã mở tệp. Nhập đúng Key rồi bấm Decrypt.");
        } catch (Exception ex) { showError(ex); }
    }
    private void setStatus(String text) { lbl_status.setText("<html>" + text + "</html>"); }
    private void showError(Exception ex) {
        lbl_status.setText("Thao tác thất bại.");
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi thao tác", JOptionPane.ERROR_MESSAGE);
    }
}
