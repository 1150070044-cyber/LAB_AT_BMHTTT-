package week_02;

import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** AES-256-GCM: Base64(salt 16 byte || nonce 12 byte || ciphertext + tag). */
public final class AESCipher {
    private static final int ITERATIONS = 120_000;
    private AESCipher() {}
    public static String encrypt(String plain, String password) throws Exception {
        CipherUtil.requireKey(password);
        byte[] salt = CipherUtil.randomBytes(16), nonce = CipherUtil.randomBytes(12);
        byte[] key = CipherUtil.pbkdf2(password.toCharArray(), salt, ITERATIONS, 256);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        return CipherUtil.b64(CipherUtil.concat(CipherUtil.concat(salt, nonce), c.doFinal(CipherUtil.utf8(plain))));
    }
    public static String decrypt(String cipherText, String password) throws Exception {
        CipherUtil.requireKey(password);
        byte[] all = CipherUtil.fromB64(cipherText);
        if (all.length < 44) throw new IllegalArgumentException("Bản mã AES-GCM quá ngắn hoặc hỏng.");
        byte[] salt = Arrays.copyOfRange(all, 0, 16), nonce = Arrays.copyOfRange(all, 16, 28);
        byte[] key = CipherUtil.pbkdf2(password.toCharArray(), salt, ITERATIONS, 256);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        return CipherUtil.text(c.doFinal(Arrays.copyOfRange(all, 28, all.length)));
    }
}
