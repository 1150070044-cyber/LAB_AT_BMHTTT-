package week_02;

import java.sql.*;
import javax.swing.table.DefaultTableModel;

/** Chỉ ghi metadata; không lưu plaintext, ciphertext hay khóa. */
public final class HistoryDao {
    private HistoryDao() {}
    public static void insert(String algorithm, String operation, String username, int inLength, int outLength) throws SQLException {
        String q = "INSERT INTO dbo.crypto_history (algorithm, operation, app_username, input_length, output_length) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = DbConfig.open(); PreparedStatement ps = c.prepareStatement(q)) {
            ps.setString(1, algorithm); ps.setString(2, operation); ps.setString(3, username);
            ps.setInt(4, inLength); ps.setInt(5, outLength); ps.executeUpdate();
        }
    }
    public static String tryInsert(String algorithm, String operation, String username, int input, int output) {
        if (!DbConfig.isReady()) return "(Chưa kết nối SQL - không lưu lịch sử)";
        try { insert(algorithm, operation, username, input, output); return "(Đã lưu lịch sử SQL)"; }
        catch (SQLException ex) { return "(Lỗi ghi lịch sử: " + ex.getMessage() + ")"; }
    }
    public static DefaultTableModel emptyModel() {
        return new DefaultTableModel(new Object[] {"ID", "Thời gian", "Thuật toán", "Thao tác", "User", "Dài vào", "Dài ra"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
    }
    public static DefaultTableModel loadLatest(int top) throws SQLException {
        DefaultTableModel model = emptyModel();
        try (Connection c = DbConfig.open(); PreparedStatement ps = c.prepareStatement(
                "SELECT TOP (?) history_id, created_at, algorithm, operation, app_username, input_length, output_length "
                + "FROM dbo.crypto_history ORDER BY history_id DESC")) {
            ps.setInt(1, top);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) model.addRow(new Object[] {rs.getLong(1), rs.getTimestamp(2), rs.getString(3),
                   rs.getString(4), rs.getString(5), rs.getInt(6), rs.getInt(7)});
            }
        }
        return model;
    }
}
