package week_02;

import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** CTR không cung cấp kiểm tra toàn vẹn; không tái sử dụng cặp key/nonce. */
public final class AESCTRCipher {
    private AESCTRCipher() {}
    public static String newKey() { return CipherUtil.b64(CipherUtil.randomBytes(32)); }
    public static String newNonce() { return CipherUtil.b64(CipherUtil.randomBytes(12)); }
    private static byte[] crypt(int mode, byte[] input, String keyB64, String nonceB64) throws Exception {
        byte[] key = CipherUtil.fromB64(keyB64), nonce = CipherUtil.fromB64(nonceB64);
        if (key.length != 32 || nonce.length != 12)
            throw new IllegalArgumentException("Key cần 32 byte và Nonce 12 byte (Base64).");
        byte[] counter = Arrays.copyOf(nonce, 16);
        counter[15] = 1;
        Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(mode, new SecretKeySpec(key, "AES"), new IvParameterSpec(counter));
        return c.doFinal(input);
    }
    public static String encrypt(String plain, String keyB64, String nonceB64) throws Exception {
        return CipherUtil.b64(crypt(Cipher.ENCRYPT_MODE, CipherUtil.utf8(plain), keyB64, nonceB64));
    }
    public static String decrypt(String data, String keyB64, String nonceB64) throws Exception {
        return CipherUtil.text(crypt(Cipher.DECRYPT_MODE, CipherUtil.fromB64(data), keyB64, nonceB64));
    }
    public static String toFile(String nonce, String data) { return "NONCE=" + nonce.trim() + "\n" + data.trim() + "\n"; }
    public static String[] fromFile(String content) {
        String[] lines = content.trim().split("\\R", 2);
        if (lines.length != 2 || !lines[0].startsWith("NONCE="))
            throw new IllegalArgumentException("Tệp phải có dòng 1 NONCE=... và dòng 2 bản mã.");
        return new String[] {lines[0].substring(6).trim(), lines[1].trim()};
    }
}
