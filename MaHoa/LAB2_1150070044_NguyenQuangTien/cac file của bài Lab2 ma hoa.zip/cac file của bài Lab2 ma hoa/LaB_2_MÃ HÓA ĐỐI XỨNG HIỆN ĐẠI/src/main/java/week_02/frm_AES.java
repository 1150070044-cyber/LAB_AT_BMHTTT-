package week_02;
public final class frm_AES extends CryptoForm {
    public frm_AES() {
        super("AES-GCM - Đăng ký / Đăng nhập", "AES-GCM", "", null, null, "normal", true,
                (s, k, a) -> AESCipher.encrypt(s, k), (s, k, a) -> AESCipher.decrypt(s, k));
    }
}
