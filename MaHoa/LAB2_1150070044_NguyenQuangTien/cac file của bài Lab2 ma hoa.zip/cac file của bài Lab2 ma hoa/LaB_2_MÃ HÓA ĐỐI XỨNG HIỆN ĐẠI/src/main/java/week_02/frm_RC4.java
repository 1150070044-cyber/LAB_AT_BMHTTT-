package week_02;
public final class frm_RC4 extends CryptoForm {
    public frm_RC4() {
        super("Mật mã RC4", "RC4", "Key", null, null, "normal", false,
                (s, k, a) -> RC4Cipher.encrypt(s, k), (s, k, a) -> RC4Cipher.decrypt(s, k));
    }
}
