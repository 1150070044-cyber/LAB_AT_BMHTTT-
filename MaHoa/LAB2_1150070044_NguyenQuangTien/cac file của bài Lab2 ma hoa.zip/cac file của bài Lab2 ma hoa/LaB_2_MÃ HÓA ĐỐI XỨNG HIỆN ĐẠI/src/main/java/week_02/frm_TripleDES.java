package week_02;
public final class frm_TripleDES extends CryptoForm {
    public frm_TripleDES() {
        super("Mật mã TripleDES", "TripleDES", "123456789012345678901234", null, null, "normal", false,
                (s, k, a) -> TripleDESCipher.encrypt(s, k), (s, k, a) -> TripleDESCipher.decrypt(s, k));
    }
}
