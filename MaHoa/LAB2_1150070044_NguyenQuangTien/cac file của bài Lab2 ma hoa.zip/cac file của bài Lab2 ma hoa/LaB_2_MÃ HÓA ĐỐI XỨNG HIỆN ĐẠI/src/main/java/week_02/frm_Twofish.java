package week_02;
public final class frm_Twofish extends CryptoForm {
    public frm_Twofish() {
        super("Mật mã Twofish", "Twofish", "MatKhauTwofish", "IV (HEX - 32 ký tự):", "", "twofish", false,
                (s, k, a) -> TwofishCipher.encrypt(s, k, a), (s, k, a) -> TwofishCipher.decrypt(s, k, a));
    }
}
