package week_02;
public final class frm_DES extends CryptoForm {
    public frm_DES() {
        super("Mật mã DES", "DES", "12345678", null, null, "normal", false,
                (s, k, a) -> DESCipher.encrypt(s, k), (s, k, a) -> DESCipher.decrypt(s, k));
    }
}
