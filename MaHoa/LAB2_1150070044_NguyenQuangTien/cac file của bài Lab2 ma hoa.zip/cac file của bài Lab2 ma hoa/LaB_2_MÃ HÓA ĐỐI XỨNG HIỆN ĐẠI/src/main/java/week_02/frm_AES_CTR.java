package week_02;
public final class frm_AES_CTR extends CryptoForm {
    public frm_AES_CTR() {
        super("AES-256-CTR", "AES-CTR", "", "Nonce (Base64):", "", "ctr", false,
                (s, k, a) -> AESCTRCipher.encrypt(s, k, a), (s, k, a) -> AESCTRCipher.decrypt(s, k, a));
    }
}
