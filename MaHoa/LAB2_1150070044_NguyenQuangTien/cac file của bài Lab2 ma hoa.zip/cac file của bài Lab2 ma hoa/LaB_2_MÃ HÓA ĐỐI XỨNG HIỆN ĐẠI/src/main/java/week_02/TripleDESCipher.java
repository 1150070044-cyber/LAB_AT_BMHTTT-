package week_02;

import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** 3DES chỉ để học; ứng dụng thực nên dùng AES-GCM. */
public final class TripleDESCipher {
    private TripleDESCipher() {}
    private static SecretKeySpec key(String key) {
        CipherUtil.requireKey(key);
        byte[] b = CipherUtil.utf8(key);
        if (b.length != 24) throw new IllegalArgumentException("Khóa TripleDES phải đúng 24 byte (ASCII). Hiện có " + b.length + " byte.");
        return new SecretKeySpec(b, "DESede");
    }
    public static String encrypt(String plain, String keyText) throws Exception {
        byte[] iv = CipherUtil.randomBytes(8);
        Cipher c = Cipher.getInstance("DESede/CBC/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, key(keyText), new IvParameterSpec(iv));
        return CipherUtil.b64(CipherUtil.concat(iv, c.doFinal(CipherUtil.utf8(plain))));
    }
    public static String decrypt(String data, String keyText) throws Exception {
        byte[] all = CipherUtil.fromB64(data);
        if (all.length < 16) throw new IllegalArgumentException("Bản mã TripleDES quá ngắn hoặc bị hỏng.");
        Cipher c = Cipher.getInstance("DESede/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, key(keyText), new IvParameterSpec(Arrays.copyOfRange(all, 0, 8)));
        return CipherUtil.text(c.doFinal(Arrays.copyOfRange(all, 8, all.length)));
    }
}
