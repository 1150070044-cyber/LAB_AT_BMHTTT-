package week_02;

import java.awt.*;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public final class frm_KetNoiSQL extends JFrame {
    private final JTextField server = new JTextField("127.0.0.1");
    private final JTextField port = new JTextField("1433");
    private final JTextField database = new JTextField("LAB2_MaHoaHienDai");
    private final JTextField username = new JTextField("lab2_user");
    private final JPasswordField password = new JPasswordField();
    private final JLabel status = new JLabel("Chưa kết nối.");

    public frm_KetNoiSQL() {
        super("Kết nối Microsoft SQL Server");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel p = new JPanel(new BorderLayout(8, 10));
        p.setBorder(new EmptyBorder(18, 18, 18, 18));
        JLabel h = new JLabel("KẾT NỐI MICROSOFT SQL SERVER");
        h.setFont(new Font("Segoe UI", Font.BOLD, 18)); p.add(h, BorderLayout.NORTH);
        JPanel form = new JPanel(new GridLayout(5, 2, 10, 10));
        form.add(new JLabel("Server:")); form.add(server);
        form.add(new JLabel("Port:")); form.add(port);
        form.add(new JLabel("Database:")); form.add(database);
        form.add(new JLabel("User:")); form.add(username);
        form.add(new JLabel("Password:")); form.add(password);
        p.add(form, BorderLayout.CENTER);
        JPanel bottom = new JPanel(new BorderLayout(6, 9));
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton test = new JButton("Test Connection");
        test.addActionListener(e -> testConnection());
        JButton history = new JButton("Xem lịch sử");
        history.addActionListener(e -> new frm_LichSu().setVisible(true));
        buttons.add(test); buttons.add(history);
        bottom.add(buttons, BorderLayout.NORTH);
        bottom.add(status, BorderLayout.CENTER);
        p.add(bottom, BorderLayout.SOUTH);
        add(p);
        setSize(580, 365); setLocationRelativeTo(null);
    }
    private void testConnection() {
        char[] pw = password.getPassword();
        try {
            DbConfig.set(server.getText().trim(), Integer.parseInt(port.getText().trim()),
                    database.getText().trim(), username.getText().trim(), pw);
            status.setText("<html>" + DbConfig.test() + "</html>");
        } catch (Exception ex) {
            DbConfig.clear(); status.setText("Kết nối thất bại.");
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Không kết nối được SQL Server", JOptionPane.ERROR_MESSAGE);
        } finally { Arrays.fill(pw, '\0'); }
    }
}
