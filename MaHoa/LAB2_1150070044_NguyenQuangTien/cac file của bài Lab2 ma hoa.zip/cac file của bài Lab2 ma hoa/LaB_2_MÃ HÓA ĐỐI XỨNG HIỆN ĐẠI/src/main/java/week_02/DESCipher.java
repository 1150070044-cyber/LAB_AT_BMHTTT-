package week_02;

import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** DES chỉ dành cho bài thực hành, không dùng để bảo mật dữ liệu thực. */
public final class DESCipher {
    private DESCipher() {}
    private static SecretKeySpec key(String key) {
        CipherUtil.requireKey(key);
        byte[] b = CipherUtil.utf8(key);
        if (b.length != 8) throw new IllegalArgumentException("Khóa DES phải đúng 8 byte (8 ký tự ASCII). Hiện có " + b.length + " byte.");
        return new SecretKeySpec(b, "DES");
    }
    public static String encrypt(String plain, String keyText) throws Exception {
        byte[] iv = CipherUtil.randomBytes(8);
        Cipher c = Cipher.getInstance("DES/CBC/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, key(keyText), new IvParameterSpec(iv));
        return CipherUtil.b64(CipherUtil.concat(iv, c.doFinal(CipherUtil.utf8(plain))));
    }
    public static String decrypt(String data, String keyText) throws Exception {
        byte[] all = CipherUtil.fromB64(data);
        if (all.length < 16) throw new IllegalArgumentException("Bản mã DES quá ngắn hoặc bị hỏng.");
        Cipher c = Cipher.getInstance("DES/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, key(keyText), new IvParameterSpec(Arrays.copyOfRange(all, 0, 8)));
        return CipherUtil.text(c.doFinal(Arrays.copyOfRange(all, 8, all.length)));
    }
}
