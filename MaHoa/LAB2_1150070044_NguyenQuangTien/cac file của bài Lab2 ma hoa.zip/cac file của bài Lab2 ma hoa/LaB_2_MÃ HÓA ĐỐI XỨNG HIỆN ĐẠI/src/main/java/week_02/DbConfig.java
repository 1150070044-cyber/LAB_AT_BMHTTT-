package week_02;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;

/** Mật khẩu SQL được nhập trên giao diện khi chạy, không lưu trong mã nguồn. */
public final class DbConfig {
    private static String server, database, user;
    private static int port;
    private static char[] password;
    private static boolean tested;
    private DbConfig() {}
    public static synchronized void set(String host, int p, String db, String username, char[] pw) {
        if (host.isBlank() || db.isBlank() || username.isBlank()) throw new IllegalArgumentException("Server, Database, User không được rỗng.");
        if (p < 1 || p > 65535) throw new IllegalArgumentException("Port ngoài khoảng 1-65535.");
        if (password != null) Arrays.fill(password, '\0');
        server = host; port = p; database = db; user = username; password = pw.clone(); tested = false;
    }
    public static synchronized void clear() {
        server = null; database = null; user = null; tested = false;
        if (password != null) Arrays.fill(password, '\0');
        password = null;
    }
    public static synchronized boolean isReady() { return tested; }
    public static synchronized Connection open() throws SQLException {
        if (server == null || password == null) throw new SQLException("Chưa nhập thông tin kết nối SQL Server.");
        String url = "jdbc:sqlserver://" + server + ":" + port
          + ";databaseName=" + database + ";encrypt=true;trustServerCertificate=true;loginTimeout=5";
        return DriverManager.getConnection(url, user, new String(password));
    }
    public static synchronized String test() throws SQLException {
        try (Connection con = open()) {
            DatabaseMetaData md = con.getMetaData();
            tested = true;
            return "Kết nối thành công: " + md.getDatabaseProductName() + " - " + con.getCatalog();
        }
    }
}
