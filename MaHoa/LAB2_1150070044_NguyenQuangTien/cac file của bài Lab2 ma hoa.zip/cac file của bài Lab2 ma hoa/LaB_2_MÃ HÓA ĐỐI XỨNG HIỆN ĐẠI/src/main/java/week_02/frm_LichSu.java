package week_02;

import java.awt.*;
import javax.swing.*;

public final class frm_LichSu extends JFrame {
    private final JTable table = new JTable(HistoryDao.emptyModel());
    private final JLabel status = new JLabel("Đang tải...");
    public frm_LichSu() {
        super("Lịch sử thao tác (SQL Server)");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(900, 475); setLayout(new BorderLayout(10, 10));
        JLabel h = new JLabel("LỊCH SỬ THAO TÁC - dbo.crypto_history");
        h.setFont(new Font("Segoe UI", Font.BOLD, 18)); add(h, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel bottom = new JPanel(new BorderLayout(10, 8));
        JButton refresh = new JButton("Tải lại");
        refresh.addActionListener(e -> loadData());
        bottom.add(refresh, BorderLayout.WEST); bottom.add(status, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        setLocationRelativeTo(null); loadData();
    }
    private void loadData() {
        try {
            table.setModel(HistoryDao.loadLatest(50));
            status.setText("Đã tải " + table.getRowCount() + " bản ghi mới nhất.");
        } catch (Exception ex) { status.setText("Không tải được lịch sử: " + ex.getMessage()); }
    }
}
