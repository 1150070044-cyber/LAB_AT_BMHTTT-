package week_02;

/** RC4 chỉ để học; không sử dụng để bảo mật thực tế. */
public final class RC4Cipher {
    private RC4Cipher() {}
    public static byte[] apply(byte[] data, byte[] key) {
        if (key.length < 1 || key.length > 256) throw new IllegalArgumentException("Khóa RC4 phải 1-256 byte.");
        int[] s = new int[256];
        for (int i = 0; i < 256; i++) s[i] = i;
        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + s[i] + (key[i % key.length] & 255)) & 255;
            int t = s[i]; s[i] = s[j]; s[j] = t;
        }
        byte[] out = new byte[data.length]; int i = 0; j = 0;
        for (int n = 0; n < data.length; n++) {
            i = (i + 1) & 255; j = (j + s[i]) & 255;
            int t = s[i]; s[i] = s[j]; s[j] = t;
            out[n] = (byte) (data[n] ^ s[(s[i] + s[j]) & 255]);
        }
        return out;
    }
    public static String encrypt(String plain, String key) {
        CipherUtil.requireKey(key);
        return CipherUtil.hex(apply(CipherUtil.utf8(plain), CipherUtil.utf8(key)));
    }
    public static String decrypt(String cipherText, String key) {
        CipherUtil.requireKey(key);
        return CipherUtil.text(apply(CipherUtil.fromHex(cipherText), CipherUtil.utf8(key)));
    }
}
