package week_02;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public final class frm_Menu extends JFrame {
    public frm_Menu() {
        super("LAB 2 - Mã hóa đối xứng hiện đại");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JPanel panel = new JPanel(new BorderLayout(12, 15));
        panel.setBorder(new EmptyBorder(24, 24, 24, 24));
        JLabel title = new JLabel("LAB 2 - MÃ HÓA ĐỐI XỨNG HIỆN ĐẠI", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        panel.add(title, BorderLayout.NORTH);
        JPanel buttons = new JPanel(new GridLayout(4, 2, 14, 12));
        addButton(buttons, "2.1 DES", () -> new frm_DES().setVisible(true));
        addButton(buttons, "2.2 TripleDES", () -> new frm_TripleDES().setVisible(true));
        addButton(buttons, "2.3 AES + Login", () -> new frm_AES().setVisible(true));
        addButton(buttons, "2.4 RC4", () -> new frm_RC4().setVisible(true));
        addButton(buttons, "2.5 Twofish", () -> new frm_Twofish().setVisible(true));
        addButton(buttons, "2.6 AES-CTR", () -> new frm_AES_CTR().setVisible(true));
        addButton(buttons, "Kết nối SQL Server", () -> new frm_KetNoiSQL().setVisible(true));
        addButton(buttons, "Xem lịch sử", () -> new frm_LichSu().setVisible(true));
        panel.add(buttons, BorderLayout.CENTER);
        JLabel footer = new JLabel("AES-CBC Python: chạy python/aes_cbc_gui.py trong VS Code", SwingConstants.CENTER);
        panel.add(footer, BorderLayout.SOUTH);
        add(panel);
        setSize(730, 400);
        setLocationRelativeTo(null);
    }
    private static void addButton(JPanel parent, String name, Runnable action) {
        JButton b = new JButton(name);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        b.addActionListener(e -> action.run());
        parent.add(b);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}
