package week_02;

import java.security.MessageDigest;
import java.sql.*;

public final class UserDao {
    private static final int ITERATIONS = 120_000;
    private UserDao() {}
    public static void register(String username, char[] password) throws SQLException {
        if (!username.matches("[A-Za-z0-9_.]{3,40}"))
            throw new IllegalArgumentException("Username: 3-40 ký tự, chữ/số/_/.");
        if (password.length < 8) throw new IllegalArgumentException("Mật khẩu tối thiểu 8 ký tự.");
        byte[] salt = CipherUtil.randomBytes(16);
        byte[] hash = CipherUtil.pbkdf2(password, salt, ITERATIONS, 256);
        try (Connection c = DbConfig.open(); PreparedStatement ps = c.prepareStatement(
                "INSERT INTO dbo.app_users(username, salt, password_hash) VALUES (?, ?, ?)")) {
            ps.setString(1, username); ps.setBytes(2, salt); ps.setBytes(3, hash); ps.executeUpdate();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 2601 || ex.getErrorCode() == 2627)
                throw new IllegalArgumentException("Username đã tồn tại.");
            throw ex;
        }
    }
    public static boolean login(String username, char[] password) throws SQLException {
        try (Connection c = DbConfig.open(); PreparedStatement ps = c.prepareStatement(
                "SELECT salt, password_hash FROM dbo.app_users WHERE username = ?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return false;
                byte[] actual = CipherUtil.pbkdf2(password, rs.getBytes(1), ITERATIONS, 256);
                return MessageDigest.isEqual(rs.getBytes(2), actual);
            }
        }
    }
    public static String newTicket() { return CipherUtil.hex(CipherUtil.randomBytes(16)); }
}
