# LAB 2 — Mã hóa đối xứng hiện đại (VS Code + SQL Server)

Đây là phiên bản viết bằng **Java Swing thuần mã nguồn để chạy trên VS Code**, thay cho phần kéo-thả NetBeans của tài liệu `LAB2_HuongDan.pdf`. Các bài, thuật toán, cơ sở dữ liệu, cấu trúc file lưu giữ theo yêu cầu PDF. Giao diện được triển khai lại để không phụ thuộc file `.form` của NetBeans.

## 1. Chuẩn bị trên Windows

1. Cài **JDK 17/21**, kiểm tra `java -version` và `javac -version`.
2. Cài **VS Code**, extension **Extension Pack for Java** và **Maven for Java**.
3. Cài **Apache Maven** (nếu VS Code không nhận Maven): `mvn -version`.
4. Cài **SQL Server Express** (instance thường là `SQLEXPRESS`) và **SSMS**.
5. Cài Python >=3.10 cho bài nâng cao AES-CBC.

## 2. Cấu hình SQL Server

1. Mở **SQL Server Configuration Manager** → **SQL Server Network Configuration** → **Protocols for SQLEXPRESS** → bật **TCP/IP**.
2. TCP/IP → Properties → IP Addresses → **IPAll**: `TCP Dynamic Ports` để trống, `TCP Port` = `14333`.
3. Trong SSMS: kết nối `localhost\SQLEXPRESS` bằng **Windows Authentication**.
4. Nhấp phải server → Properties → Security → chọn **SQL Server and Windows Authentication mode**.
5. Restart dịch vụ **SQL Server (SQLEXPRESS)** trong Configuration Manager.
6. Trong SSMS, mở file **`sql/01_Tao_CSDL.sql`**, bấm **Execute/F5**.
7. Chạy tiếp **`sql/02_Tao_Tai_Khoan_SQL.sql`** để tạo `lab2_user`. Mật khẩu ví dụ trong PDF là `LabUser@2026` (chỉ dùng để thực hành trên máy cá nhân). Nếu đã có login này với mật khẩu khác, script không đổi mật khẩu cũ.
8. Kiểm tra: SSMS → Connect → Database Engine → Server name: **`127.0.0.1,14333`** (dấu **phẩy**), Authentication: **SQL Server Authentication**, Login: `lab2_user`, Password: `LabUser@2026`. Nếu được yêu cầu, tích **Trust server certificate**.

**Lưu ý**: SSMS và chương trình Java là hai ứng dụng khác nhau; SSMS dùng để chạy script SQL và đối chiếu dữ liệu, còn Java kết nối qua JDBC.

## 3. Mở project trong VS Code

1. Giải nén ZIP, mở VS Code → **File → Open Folder** → chọn `LAB2_VSCode_SQLServer` (thư mục chứa `pom.xml`).
2. Chờ **Java Projects / Maven** nhận diện và tải thư viện (cần internet lần đầu).
3. Trong Terminal (Ctrl+`), chạy:

   ```powershell
   mvn clean compile
   mvn exec:java
   ```

4. Hoặc mở `src/main/java/week_02/frm_Menu.java`, tại hàm `main` bấm **Run Java**. Có thể dùng `Run and Debug` → **Chạy LAB 2 - Menu**.
5. Menu hiện 8 nút như đề. Để ghi lịch sử, hãy **Kết nối SQL Server** trước.

Nếu bạn tự tạo Maven project thay vì giải nén, có thể chép nguyên `pom.xml` từ gói này; mã Java nằm trong package `week_02`.

## 4. Thứ tự thực hành

### Bước A: Kiểm tra SQL
- Bấm **Kết nối SQL Server** trong Menu.
- Server: `127.0.0.1`; Port: `14333`; Database: `LAB2_MaHoaHienDai`;
  User: `lab2_user`; Password nhập mật khẩu đã tạo trong SSMS.
- Bấm **Test Connection**, cần xuất hiện **Kết nối thành công**.

### Bước B: Bài 2.1 — DES
- Plaintext: `Xin chào Lab 2 - Mã hóa hiện đại!`.
- Key: `12345678` (đúng 8 byte ASCII).
- Bấm Encrypt → xóa Plaintext → Decrypt → khôi phục nguyên văn.
- Bấm Encrypt hai lần, ciphertext phải khác nhau vì IV ngẫu nhiên.
- Test Save File → Open File → Decrypt.

### Bước C: Bài 2.2 — TripleDES
- Key: `123456789012345678901234` (24 ký tự ASCII).
- Encrypt → Decrypt; thử Key 23 ký tự phải báo lỗi.

### Bước D: Bài 2.3 — AES-GCM + Login
- Kết nối SQL trước.
- Mở **2.3 AES + Login**.
- Username (mới): `sinhvien01`; Password: tự đặt từ 8 ký tự trở lên.
- Bấm Register → Login → ô Ticket xuất hiện giá trị 32 ký tự HEX.
- Nhập Key AES khác mật khẩu tài khoản nếu muốn; bấm Encrypt/Decrypt.
- Xem bảng `dbo.app_users` và `dbo.crypto_history` bằng SSMS.

### Bước E: Bài 2.4 — RC4
- Plaintext: `Plaintext`; Key: `Key`.
- Encrypt → ciphertext HEX **BBF316E8D940AF0AD3**.
- Decrypt → `Plaintext`.

### Bước F: Bài 2.5 — Twofish
- Giữ Key cố định, bấm **Generate IV**, Encrypt → Decrypt.
- Save File sẽ lưu **IV=...** ở dòng đầu và bản mã ở dòng hai, **không lưu Key**.
- Open File khôi phục IV; nhập lại Key và bấm Decrypt.

### Bước G: Bài 2.6 — AES-CTR
- Generate Key (32 byte, Base64) → Generate Nonce (12 byte, Base64).
- Encrypt → Decrypt đúng nguyên văn, kể cả văn bản dài.
- Lưu ý: không dùng lại cùng một cặp Key + Nonce cho hai thông điệp khác nhau; nên Generate Nonce mới mỗi lần mã hóa với một khóa đã có.

### Bước H: AES-CBC Python
Trong terminal tại thư mục project:

```powershell
py -m pip install -r python/requirements.txt
py python/aes_cbc_gui.py --self-test
py python/aes_cbc_gui.py
```

Self-test cần hiện `SELF-TEST OK`. Giao diện Tkinter sẽ mở; bấm Generate Key, Generate IV, nhập Plaintext, thử Encrypt/Decrypt, Save File/Open File.

## 5. Kiểm tra bảng SQL sau các bài

Mở SSMS, chạy `sql/03_Kiem_Tra_Du_Lieu.sql`.

- `dbo.app_users`: tài khoản đã Register, lưu `salt` và `password_hash` chứ không lưu mật khẩu gốc.
- `dbo.crypto_history`: dòng thao tác Encrypt/Decrypt; chỉ lưu tên thuật toán và độ dài dữ liệu, **không lưu bản rõ hay khóa**.

## 6. Lỗi thường gặp

| Lỗi | Cách xử lý |
|---|---|
| `mvn` không được nhận diện | Cài Maven, thêm `bin` của Maven vào PATH, mở lại VS Code. |
| `java` không được nhận diện | Cài JDK 17/21, cấu hình JAVA_HOME / PATH. |
| Maven không tải thư viện | Kiểm tra internet, proxy, Maven settings; thử `mvn -U clean compile`. |
| `package org.bouncycastle... does not exist` | Maven chưa tải `bcprov-jdk18on`; kiểm tra `pom.xml`. |
| `No suitable driver found for jdbc:sqlserver` | Maven chưa tải `mssql-jdbc`; dùng `mvn exec:java` hoặc Run Java trong project Maven. |
| TCP/IP connection to port 14333 failed | Bật TCP/IP, cấu hình IPAll port `14333`, restart dịch vụ SQL; kiểm tra port thực tế. |
| `Login failed for user` | Kiểm tra Mixed Mode, login `lab2_user`, mật khẩu, quyền và restart dịch vụ. |
| Không thấy bảng vừa tạo | Mở đúng database `LAB2_MaHoaHienDai`, Refresh Databases. |
| Sai Key/IV khi Decrypt | Nhập lại đúng Key và IV/Nonce đã dùng lúc Encrypt. |
| Python báo thiếu `cryptography` | Chạy `py -m pip install -r python/requirements.txt`. |

## 7. Sơ đồ các file quan trọng

```text
LAB2_VSCode_SQLServer/
  pom.xml
  .vscode/launch.json
  sql/
    01_Tao_CSDL.sql
    02_Tao_Tai_Khoan_SQL.sql
    03_Kiem_Tra_Du_Lieu.sql
  src/main/java/week_02/
    CipherUtil.java, FileTextIO.java
    DbConfig.java, UserDao.java, HistoryDao.java
    DESCipher.java, TripleDESCipher.java, AESCipher.java
    RC4Cipher.java, TwofishCipher.java, AESCTRCipher.java
    CryptoForm.java
    frm_Menu.java, frm_KetNoiSQL.java, frm_LichSu.java
    frm_DES.java, frm_TripleDES.java, frm_AES.java
    frm_RC4.java, frm_Twofish.java, frm_AES_CTR.java
  python/
    aes_cbc_gui.py
    requirements.txt
```

## 8. Khác biệt so với hướng dẫn NetBeans

Tài liệu PDF gốc hướng dẫn tạo `JFrame Form` bằng kéo-thả. VS Code không đi kèm NetBeans GUI Builder nên bộ này thay bằng `CryptoForm.java`, xây dựng Swing qua mã nguồn. Tất cả các form bài tập vẫn có cùng tên và nút chức năng; giao diện có thể khác về bố cục nhưng cùng mục đích và kiểm thử.

**Lưu ý an toàn**: DES/3DES/RC4 là thuật toán cũ, không dùng cho ứng dụng bảo mật dữ liệu thực. Tài khoản `lab2_user` / mật khẩu minh họa chỉ dùng cho lab cục bộ; không dùng lại mật khẩu này trong hệ thống thực tế. Chuỗi `trustServerCertificate=true` cũng chỉ hợp lý trong môi trường học tập có SQL Server tự ký chứng chỉ.
